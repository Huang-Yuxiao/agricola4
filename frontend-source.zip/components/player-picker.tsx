'use client';
import { Combobox, ComboboxInput, ComboboxContent, ComboboxList, ComboboxItem, ComboboxEmpty } from '@/components/ui/combobox';
import history from '@/lib/history.json';
const names=history.map(p=>p.name);
export function PlayerPicker({value,onChange,index,options=names}:{value:string;onChange:(value:string)=>void;index:number;options?:string[]}){
  return <Combobox items={options} inputValue={value} value={options.includes(value)?value:null} onInputValueChange={onChange} onValueChange={v=>{if(v!==null)onChange(v);}}>
    <ComboboxInput aria-label={`玩家${index+1}昵称`} placeholder="选历史玩家或填新名" maxLength={40} required className="player-picker"/>
    <ComboboxContent className="player-picker-popup">
      <ComboboxEmpty>无匹配玩家，将使用你输入的新名字。</ComboboxEmpty>
      <ComboboxList>{(name:string)=><ComboboxItem key={name} value={name}>{name}</ComboboxItem>}</ComboboxList>
    </ComboboxContent>
  </Combobox>;
}
