import { useId } from 'react';
import { Input } from '@/components/ui/input';
export function PlayerPicker({value,onChange,index,options=[],required=true}:{value:string;onChange:(value:string)=>void;index:number;options?:string[];required?:boolean}){
 const id=useId();
 return <><Input list={id} aria-label={`玩家${index+1}昵称`} placeholder="搜索并选择已登记ID" maxLength={40} required={required} className="player-picker" value={value} onChange={e=>onChange(e.target.value)}/><datalist id={id}>{options.map(name=><option key={name} value={name}/>)}</datalist></>;
}
