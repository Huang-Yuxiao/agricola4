import { useState } from 'react';
import { apiFetch } from '@/lib/api';
import type { RecordItem } from '@/lib/records';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog,DialogContent,DialogHeader,DialogTitle,DialogDescription,DialogFooter } from '@/components/ui/dialog';

export function MatchNpc({match,onClose,onSaved}:{match:RecordItem;onClose:()=>void;onSaved:(message:string)=>void}){
 const [selected,setSelected]=useState<string[]>(()=>match.players.filter(p=>p.manualNpc).map(p=>p.name));
 const [password,setPassword]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState('');
 async function save(e:React.FormEvent){
  e.preventDefault();if(busy)return;setBusy(true);setError('');
  try{
   const r=await apiFetch(`/api/submissions/${encodeURIComponent(match.id)}/npc`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password,revision:match.revision,npcNames:selected})});
   const d=await r.json();if(!r.ok)throw new Error(d.error||'保存失败');
   onSaved(`#${match.tableId} 的NPC设置已保存，榜单已按原顺序重新结算。`);
  }catch(e){setError(e instanceof Error?e.message:'保存失败，请刷新核对后重试');}finally{setBusy(false);}
 }
 return <Dialog open onOpenChange={open=>{if(!open&&!busy)onClose();}}><DialogContent className="max-h-[90dvh] overflow-y-auto" showCloseButton={!busy}><DialogHeader><DialogTitle>设置本局 NPC · {match.platform} #{match.tableId}</DialogTitle><DialogDescription>可勾选多名玩家。指定NPC在本局不改变自己的秋季分，不增加赛季计分局数，也不获得+5奖励；全阶段成绩、实打局数及活跃奖统计照常。其他玩家仍正常与其结算。</DialogDescription></DialogHeader><form onSubmit={save} className="grid gap-4"><fieldset disabled={busy} className="grid gap-3"><legend className="text-sm mb-2">选择本局不计秋季分的玩家</legend>{match.players.map(p=><label key={p.name} className="flex items-start gap-3 rounded-md border p-3"><input type="checkbox" className="mt-1 h-4 w-4 shrink-0 accent-green-800" aria-label={`指定 ${p.name} 为本局NPC`} checked={selected.includes(p.name)} onChange={e=>setSelected(ns=>e.target.checked?[...ns,p.name]:ns.filter(n=>n!==p.name))}/><span className="break-all">{p.name}<small className="block text-muted-foreground">第{p.rank}名 · {p.rawScore??p.score}分{p.npc&&!p.manualNpc?' · 当前已自动NPC':''}</small></span></label>)}<p className="input-help">取消勾选可恢复本局正常计分；已达550或15局的自动NPC规则仍然生效。修改旧局会重算后续赛季分、锁分时间和奖金预测，原有对局顺序与上报时间不变。</p><label>管理员密码<Input aria-label="NPC管理员密码" type="password" autoComplete="off" required maxLength={256} value={password} onChange={e=>setPassword(e.target.value)}/></label>{error&&<p role="alert" className="error">{error}</p>}<DialogFooter><Button type="button" variant="outline" disabled={busy} onClick={onClose}>取消</Button><Button type="submit" disabled={busy||!password}>{busy?'正在保存…':'保存NPC设置'}</Button></DialogFooter></fieldset></form></DialogContent></Dialog>;
}
