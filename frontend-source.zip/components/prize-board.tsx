import { Search, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

type PrizeRow={name:string;rank:number|null;playedGames:number;scoredGames:number;extraGames:number;projectedQualified:boolean;participation:number;participationIfNotQualified:number;hypotheticalParticipantCount:number;activity:number;currentAllocation:number;projectedPlacement:number;projectedTotal:number;personalBest:number;highestCandidate:number};
export type Prizes={ruleVersion:string;totalPool:number;placementReserve:number;sharedPool:number;participationPool:number;activityPool:number;highestPool:number;participantCount:number;activityWeight:number;activityParticipants:number;matchCount:number;playerCount:number;unallocatedParticipation:number;unallocatedActivity:number;highestScore:number|null;highestPlayers:string[];rows:PrizeRow[]};
const money=(n:number)=>n.toLocaleString('zh-CN',{minimumFractionDigits:2,maximumFractionDigits:2});
export function PrizeBoard({data,search,setSearch,loading,error,refresh}:{data:Prizes|null;search:string;setSearch:(s:string)=>void;loading:boolean;error:string;refresh:()=>void}){
 const rows=(data?.rows??[]).filter(p=>p.name.toLowerCase().includes(search.trim().toLowerCase()));
 return <section className="panel prize-board"><div className="panel-heading"><div><h2>我的奖金明细</h2><p>用已经打完的局数，看看现在分到多少，以及按当前名次预计能拿多少。</p></div><Button size="sm" variant="outline" onClick={refresh} disabled={loading}><RefreshCw size={14}/>{loading?'更新中':'刷新'}</Button></div>
 {error&&<p className="error" role="alert">{error} 当前保留上次读取的奖金，请刷新重试。</p>}
 {!data?<p className="empty">{loading?'正在读取奖金明细…':'奖金数据暂未就绪，请刷新重试。'}</p>:<>
 <div className="prize-summary"><div><span>赛事总奖池</span><strong>¥{money(data.totalPool)}</strong><small>预计名次奖预留 ¥{money(data.placementReserve)}</small></div><div><span>参与奖池 · 50%</span><strong>¥{money(data.participationPool)}</strong><small>目前 {data.participantCount} 人满足满6局且不在前16</small></div><div><span>活跃奖池 · 50%</span><strong>¥{money(data.activityPool)}</strong><small>{data.activityParticipants} 人，共 {data.activityWeight} 个超6局权重</small></div></div>
 <div className="prize-explainer"><strong>当前分配 ≠ 已发放，预计奖金 ≠ 最终奖金</strong><p>当前分配按已完成的初赛局数和当前前16名单暂算，只包含参与奖、活跃奖。预计总奖金再加名次奖。后续对局、名次和最终奖池变化都会更新金额。</p><details className="prize-assumptions"><summary>查看预计名次与奖池假设</summary><p>暂定秋季榜前16晋级，复赛／决赛最终名次与现在一致；沿用海报前4名每人220分、第5—16名每人100分的假设，名次奖共1868元，另预留最高分奖50元，剩余432元均分为两个216元奖池。最终按实际轮次得分重算，剩余奖池保底300元，不足由道哥补齐。</p></details></div>
 <div className="search"><Search size={18}/><Input aria-label="搜索奖金玩家" placeholder="输入参赛 ID，查看自己的奖金…" value={search} onChange={e=>setSearch(e.target.value)}/></div>
 <p className="prize-count">已统计 {data.matchCount} 场初赛 · {data.playerCount} 位参赛玩家 · 每10分钟更新，也可手动刷新</p>
 <div className="prize-players">{rows.map(p=><article className="prize-player" key={p.name}>
 <div className="prize-player-heading"><h3>{p.name}</h3><span className="soft-tag">{p.rank?`秋季榜第 ${p.rank} 名`:'暂无秋季排名'} · {p.projectedQualified?'暂按晋级':'暂按未晋级'}</span></div>
 <div className="prize-games"><div><strong>{p.playedGames}</strong><span>初赛实打局数</span></div><div><strong>{p.extraGames}</strong><span>活跃奖权重（超6局）</span></div><p>含自动NPC、锁分后及超过15局的对局。<br/>与赛季计分局数独立统计。</p></div>
 <div className="prize-totals"><div><span>当前按局数分配 · 暂算</span><strong>¥{money(p.currentAllocation)}</strong><small>参与 ¥{money(p.participation)} + 活跃 ¥{money(p.activity)}</small></div><div><span>按当前名次预计总奖金</span><strong>¥{money(p.projectedTotal)}</strong><small>当前分配 + 预计名次奖 ¥{money(p.projectedPlacement)}</small></div></div>
 <details className="prize-details"><summary>展开奖金计算明细</summary><dl>
 <div><dt>参与奖（当前名单）</dt><dd>¥{money(p.participation)}<small>{p.playedGames<6?`还差 ${6-p.playedGames} 局满6局` :p.projectedQualified?'暂列前16，预计晋级，不与名次奖重复领取':`¥${money(data.participationPool)} ÷ ${data.participantCount} 名符合条件的玩家`}</small></dd></div>
 <div><dt>假如未进前16，可分参与奖</dt><dd>¥{money(p.participationIfNotQualified)}<small>{p.playedGames<6?'未满6局，暂不满足参与奖条件':`只将你按未晋级计算，其他人资格不变：¥${money(data.participationPool)} ÷ ${p.hypotheticalParticipantCount} 人。此项是另一种情景，不叠加到上面总额。`}</small></dd></div>
 <div><dt>活跃奖（所有选手）</dt><dd>¥{money(p.activity)}<small>{data.activityWeight?`¥${money(data.activityPool)} × ${p.extraGames} ÷ ${data.activityWeight}`:'尚无人超过6局，活跃奖池暂待分配'}{p.extraGames===0&&data.activityWeight>0?'；第7局起开始增加权重':''}</small></dd></div>
 <div><dt>预计名次奖</dt><dd>¥{money(p.projectedPlacement)}<small>{p.projectedQualified?(p.rank!<=4?`基数 ${[200,150,100,50][p.rank!-1]} + 假设220分 × 系数 ${[1,.9,.8,.7][p.rank!-1]}`:p.rank!<=8?'基数25 + 假设100分 × 系数0.5':'基数0 + 假设100分 × 系数0.4'):'当前在前16之外，预计不领取名次奖'}</small></dd></div>
 <div><dt>本届单局最高分奖候选</dt><dd>{p.highestCandidate?`暂列 ¥${money(p.highestCandidate)}`:'暂未领跑'}<small>个人最高 {p.personalBest} 分。{p.highestCandidate?`当前 ${data.highestPlayers.length} 个ID并列，平分50元。`:''}赛事未结束，此奖不计入上述总额。</small></dd></div>
 </dl></details></article>)}</div>
 {!rows.length&&<p className="empty">{search?'没有找到这个参赛ID。':'尚无本届参赛记录。'}</p>}
 <div className="prize-explainer"><strong>单局最高分奖 · ¥50</strong><p>{data.highestScore===null?'等待本届成绩。':`目前最高 ${data.highestScore} 分：${data.highestPlayers.join('、')}。`}覆盖本届初赛、复赛和决赛；按原始分比较，不含Studio奖励和0.001破平调整；同一ID多次达最高分也只占一份。</p><p>参与奖：初赛满6局且未晋级者均分。活跃奖：个人超6局数 ÷ 全体超6局数 × 活跃奖池，所有选手可参与。初赛实打局数从本届有效对局逐场统计，历史补录不计入；删除或修改对局后自动重算。金额展示到分，最终结算处理分币尾差。</p>{(data.unallocatedParticipation>0||data.unallocatedActivity>0)&&<p>当前待分配：参与奖 ¥{money(data.unallocatedParticipation)}；活跃奖 ¥{money(data.unallocatedActivity)}。</p>}</div>
 </>}
 </section>;
}
