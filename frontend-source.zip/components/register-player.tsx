import { useState } from 'react';
import { apiFetch } from '@/lib/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog,DialogContent,DialogHeader,DialogTitle,DialogDescription,DialogFooter } from '@/components/ui/dialog';

export function RegisterPlayer({onSaved,disabled}:{onSaved:()=>void;disabled:boolean}){
 const [open,setOpen]=useState(false),[name,setName]=useState(''),[password,setPassword]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState(''),[status,setStatus]=useState('');
 async function save(e:React.FormEvent){
  e.preventDefault();if(busy)return;setBusy(true);setError('');
  try{
   const r=await apiFetch('/api/players',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,password})});
   const d=await r.json();if(!r.ok)throw new Error(d.error||'添加失败');
   setStatus(`已添加 ${d.name}：全阶段500分、0局，可在上报页选择。`);setOpen(false);setPassword('');setName('');onSaved();
  }catch(e){setError(e instanceof Error?e.message:'添加失败，请重试');}finally{setBusy(false);}
 }
 return <><Button variant="outline" size="sm" disabled={disabled} onClick={()=>{setError('');setPassword('');setOpen(true);}}>添加新ID</Button>{status&&<p role="status" className="input-help">{status}</p>}<Dialog open={open} onOpenChange={v=>{if(!busy){setOpen(v);if(!v)setPassword('');}}}><DialogContent className="max-h-[90dvh] overflow-y-auto" showCloseButton={!busy}><DialogHeader><DialogTitle>添加新玩家ID</DialogTitle><DialogDescription>请输入准确的参赛ID。添加后即进入全阶段榜，初始500分、0局；首次参赛时秋季分从450开始。已有ID及历史别名不能重复添加。</DialogDescription></DialogHeader><form onSubmit={save} className="grid gap-4"><fieldset disabled={busy} className="grid gap-4"><label>参赛ID<Input aria-label="新玩家ID" value={name} onChange={e=>setName(e.target.value)} maxLength={40} required autoFocus/></label><label>管理员密码<Input aria-label="添加ID管理员密码" type="password" autoComplete="off" value={password} onChange={e=>setPassword(e.target.value)} required maxLength={256}/></label>{error&&<p role="alert" className="error">{error}</p>}<DialogFooter><Button type="button" variant="outline" disabled={busy} onClick={()=>{setOpen(false);setPassword('');}}>取消</Button><Button disabled={busy||!name.trim()||!password} type="submit">{busy?'正在添加…':'确认添加ID'}</Button></DialogFooter></fieldset></form></DialogContent></Dialog></>;
}
