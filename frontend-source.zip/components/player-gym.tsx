import { useState } from 'react';
import { apiFetch } from '@/lib/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog,DialogContent,DialogHeader,DialogTitle,DialogDescription,DialogFooter } from '@/components/ui/dialog';
export function PlayerGym({name,gym,onSaved,refresh}:{name:string;gym:string;onSaved:(name:string,gym:string)=>void;refresh:()=>void}){
 const [open,setOpen]=useState(false),[value,setValue]=useState(gym),[busy,setBusy]=useState(false),[error,setError]=useState('');
 async function save(e:React.FormEvent){e.preventDefault();if(busy)return;setBusy(true);setError('');try{
  const r=await apiFetch('/api/players/gym',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,gym:value,expectedGym:gym})});
  const d=await r.json();if(!r.ok){if(r.status===409)refresh();throw new Error(d.error||'保存失败');}
  onSaved(d.name,d.gym);setOpen(false);
 }catch(e){setError(e instanceof Error?e.message:'保存失败，请重试');}finally{setBusy(false);}}
 return <><button type="button" className="max-w-32 whitespace-normal break-words text-left text-sm text-emerald-700 underline decoration-dotted underline-offset-4" aria-label={`修改 ${name} 道馆`} onClick={()=>{setValue(gym);setError('');setOpen(true);}}>{gym||'未设置'}</button><Dialog open={open} onOpenChange={v=>{if(!busy)setOpen(v);}}><DialogContent className="max-h-[90dvh] overflow-y-auto" showCloseButton={!busy}><DialogHeader><DialogTitle>修改道馆 · {name}</DialogTitle><DialogDescription>无需管理员密码。两个榜单共用此玩家的道馆，保存后同步；留空可清除。任何人均可修改，请准确填写。</DialogDescription></DialogHeader><form onSubmit={save} className="grid gap-4"><label>道馆<Input aria-label="道馆名称" value={value} maxLength={60} disabled={busy} onChange={e=>setValue(e.target.value)} autoFocus/></label>{error&&<p className="error" role="alert">{error}</p>}<DialogFooter><Button type="button" variant="outline" disabled={busy} onClick={()=>setOpen(false)}>取消</Button><Button type="submit" disabled={busy}>{busy?'保存中…':'保存道馆'}</Button></DialogFooter></form></DialogContent></Dialog></>;
}
