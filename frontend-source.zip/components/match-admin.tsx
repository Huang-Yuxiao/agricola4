import { useState } from 'react';
import { apiFetch } from '@/lib/api';
import { submissionSchema } from '@/lib/submission';
import type { RecordItem } from '@/lib/records';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { PlayerPicker } from '@/components/player-picker';
import { Dialog,DialogContent,DialogHeader,DialogTitle,DialogDescription,DialogFooter } from '@/components/ui/dialog';

export function MatchAdmin({match,action,names,onClose,onSaved}:{match:RecordItem;action:'edit'|'move';names:string[];onClose:()=>void;onSaved:(message:string)=>void}){
 const [platform,setPlatform]=useState(match.platform),[mode,setMode]=useState(match.mode),[tableId,setTableId]=useState(match.tableId),[note,setNote]=useState(match.note);
 const [players,setPlayers]=useState(()=>match.players.map(p=>({name:p.name,score:String(p.rawScore??p.score),rank:p.rank})));
 const [target,setTarget]=useState(''),[password,setPassword]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false);
 const editing=action==='edit';
 function update(i:number,field:string,value:string|number){setPlayers(ps=>ps.map((p,j)=>i===j?{...p,[field]:value}:p));}
 async function submit(e:React.FormEvent){
  e.preventDefault();if(busy)return;setError('');
  let body:unknown;
  if(editing){
   if(players.some(p=>!p.score.trim())){setError('请填写每位玩家的得分，0 分请明确填 0。');return;}
   const parsed=submissionSchema.safeParse({id:match.id,platform,mode,tableId,note,players:players.map(p=>({...p,score:Number(p.score)}))});
   if(!parsed.success){setError(parsed.error.issues[0].message);return;}
   body={password,revision:match.revision,submission:parsed.data};
  }else{
   if(target.trim().toLowerCase()===match.tableId.toLowerCase()){setError('不能插入到本局自己之前');return;}
   body={password,beforeTableId:target.trim()};
  }
  setBusy(true);
  try{
   const r=await apiFetch(`/api/submissions/${encodeURIComponent(match.id)}/${action}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
   const d=await r.json();if(!r.ok)throw new Error(d.error||'保存失败');
   onSaved(editing?`#${tableId} 已修改，原有计分顺序不变，榜单已重新结算。`:`#${match.tableId} 已插入 #${target.trim()} 之前计分，榜单已重新结算。`);
  }catch(e){setError(e instanceof Error?e.message:'网络异常，请刷新核对后重试');}finally{setBusy(false);}
 }
 return <Dialog open onOpenChange={open=>{if(!open&&!busy)onClose();}}><DialogContent showCloseButton={!busy} className={editing?'sm:max-w-2xl max-h-[90vh] overflow-y-auto':''}><DialogHeader><DialogTitle>{editing?'修改对局':'调整计分顺序'} {match.platform} #{match.tableId}</DialogTitle><DialogDescription>{editing?'修改后保留本局原有位置、回执和上报时间，并重算后续 ELO、局数与均分。':'输入目标桌号，本局会在该局之前计分；其他对局之间的先后顺序不变。记录页最新在上，因此移动后本局显示在目标局下方。'}</DialogDescription></DialogHeader><form onSubmit={submit} className="grid gap-4"><fieldset disabled={busy} className="grid gap-4">{editing?<><div className="field-grid"><label>平台<select aria-label="修改平台" value={platform} onChange={e=>setPlatform(e.target.value as typeof platform)}><option>Studio</option><option>BGA</option></select></label><label>模式<select aria-label="修改模式" value={mode} onChange={e=>setMode(e.target.value as typeof mode)}><option>即时</option><option>回合制</option></select></label><label>桌号<Input aria-label="修改桌号" value={tableId} onChange={e=>setTableId(e.target.value)} required maxLength={80}/></label></div><div><div className="player-labels"><span>玩家昵称</span><span>原始得分</span><span>名次</span></div>{players.map((p,i)=><div className="player-row" key={i}><PlayerPicker options={names} value={p.name} index={i} onChange={name=>update(i,'name',name)}/><Input aria-label={`修改玩家${i+1}得分`} type="number" step="any" min="-1000" max="10000" value={p.score} onChange={e=>update(i,'score',e.target.value)} required/><select aria-label={`修改玩家${i+1}名次`} value={p.rank} onChange={e=>update(i,'rank',Number(e.target.value))}>{[1,2,3,4].map(n=><option key={n} value={n}>第 {n} 名</option>)}</select></div>)}<p className="input-help">同分不同名次会自动加 0.001 区分；真正并列请填相同名次。无需自行加 G 奖励。</p></div><label>备注<Input aria-label="修改备注" value={note} onChange={e=>setNote(e.target.value)} maxLength={500}/></label></>:<label>插入到哪个桌号之前<Input aria-label="目标桌号" value={target} onChange={e=>setTarget(e.target.value)} placeholder="输入已上报的目标桌号" required maxLength={80} autoFocus/></label>}<label>管理员密码<Input aria-label="管理员密码" type="password" autoComplete="off" value={password} onChange={e=>setPassword(e.target.value)} required maxLength={256}/></label>{error&&<p role="alert" className="error">{error}</p>}<DialogFooter><Button type="button" variant="outline" onClick={onClose} disabled={busy}>取消</Button><Button type="submit" disabled={busy||!password}>{busy?'正在保存…':editing?'保存修改':'确认调整顺序'}</Button></DialogFooter></fieldset></form></DialogContent></Dialog>;
}
