declare global { interface Window { AGRICOLA_API?:string } }
export async function apiFetch(route:string, options:RequestInit={}) {
 const base=window.AGRICOLA_API?.replace(/\/$/,'');
 if(!base)throw new Error('计分服务正在迁移，暂未开放提交。请稍后再试。');
 try{return await fetch(base+route,{...options,credentials:'omit',signal:AbortSignal.timeout(15000)});}
 catch {throw new Error('暂时连接不上计分服务器，请稍后重试；未收到保存成功回执前，请勿视为已提交。');}
}
