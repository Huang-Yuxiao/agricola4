declare global { interface Window { AGRICOLA_API?:string } }
export async function apiFetch(route:string, options:RequestInit={}) {
 const base=window.AGRICOLA_API?.replace(/\/$/,'');
 if(!base)throw new Error('计分服务正在迁移，暂未开放提交。请稍后再试。');
 const readOnly=['GET','HEAD'].includes((options.method??'GET').toUpperCase());
 const attempts=readOnly?2:1;
 for(let attempt=0;attempt<attempts;attempt++){
  try{
   const response=await fetch(base+route,{...options,credentials:'omit',signal:AbortSignal.timeout(30000)});
   // The timeout also applies while downloading the body. Consume it here so
   // a slow body is retried for reads and never leaks a raw TimeoutError.
   if(response.status===204||response.status===205||options.method?.toUpperCase()==='HEAD')return response;
   const body=await response.arrayBuffer();
   const headers=new Headers(response.headers);headers.delete('content-encoding');headers.delete('content-length');
   return new Response(body,{status:response.status,statusText:response.statusText,headers});
  }catch{
   if(attempt+1===attempts)throw new Error(readOnly?'榜单连接超时，已自动重试一次。请稍后点击刷新；原有成绩已保存在服务器。':'暂时连接不上计分服务器，请稍后核对对局记录；未收到保存成功回执前，请勿视为已提交。');
  }
 }
 throw new Error('暂时连接不上计分服务器，请稍后重试。');
}
