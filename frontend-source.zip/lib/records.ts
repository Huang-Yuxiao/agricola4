import type { Submission } from '@/lib/submission';
import type { PlayerChange } from '@/lib/ratings';
export type RecordItem=Omit<Submission,'players'> & {players:(Submission['players'][number]&{rawScore?:number;tieBreakBonus?:number})[];finishedAt:string;timeSource?:'reported';createdAt:string;status:string;revision:string;sequence:number;scoringNumber:number;ratingChanges?:PlayerChange[]};
