import aliases from './player-aliases.json';
import history from './history.json';
export const identityKey=(name:string)=>name.normalize('NFKC').trim().replace(/\s+/g,' ').toLocaleLowerCase('en-US');
const names=new Map(history.map(p=>[identityKey(p.name),p.name]));
for(const [raw,canonical] of Object.entries(aliases))names.set(identityKey(raw),canonical);
export function canonicalName(name:string){return names.get(identityKey(name))??name.normalize('NFKC').trim().replace(/\s+/g,' ');}
