export type RatingPlayer={name:string;globalElo:number;globalGames:number;scoreTotal:number;seasonElo:number;seasonGames:number;achievedAt:string|null;lockedAt?:string|null;seasonLocked?:boolean;lockReason?:string|null};
export type RatingMatch={id:string;platform:'BGA'|'Studio';mode:'即时'|'回合制';finishedAt:string;startedAt?:string;timeSource?:'reported';createdAt:string;players:{name:string;score:number;rank:number;npc?:boolean}[]};
export type SeedRow={name:string;elo:string;games:string;avg_score:string};
export type PlayerChange={name:string;globalBefore:number;globalDelta:number;globalAfter:number;seasonBefore:number;seasonDelta:number;bonus:number;seasonAfter:number;seasonGames:number;seasonCounted:boolean;reason:string;autoNpc:boolean;seasonCapAdjustment:number};
export type MatchResult={id:string;players:PlayerChange[]};
export type RatingPolicy={globalK:'legacy'|'fixed';prequalifiedAsync:boolean};
export const SEASON_START=Date.parse('2026-10-02T00:00:00+08:00');
export const SEASON_END=Date.parse('2026-10-26T00:00:00+08:00');
export const ASYNC_START_END=Date.parse('2026-10-11T00:00:00+08:00');
export const globalK=(games:number)=>games<10?40:games<20?80/3:40/3;
export const expected=(self:number,opponent:number)=>1/(1+10**((opponent-self)/400));
export function matchDeltas(players:{globalElo:number;globalGames:number;seasonElo:number;rank:number}[],policy:RatingPolicy){
 return players.map((p,i)=>{let globalDelta=0,seasonDelta=0;for(let j=0;j<players.length;j++){if(i===j)continue;const q=players[j],w=p.rank<q.rank?1:p.rank===q.rank?.5:0;
  globalDelta+=(policy.globalK==='legacy'?globalK(p.globalGames):40/3)*(w-expected(p.globalElo,q.globalElo));
  seasonDelta+=(40/3)*(w-expected(p.seasonElo,q.globalElo));
 }return {globalDelta,seasonDelta};});
}
export function calculateRankings(seed:SeedRow[],matches:RatingMatch[],policy:RatingPolicy){
 const players=new Map<string,RatingPlayer>();
 for(const row of seed)players.set(row.name,{name:row.name,globalElo:Number(row.elo),globalGames:Number(row.games),scoreTotal:Number(row.avg_score)*Number(row.games),seasonElo:450,seasonGames:0,achievedAt:null});
 const qualified=new Map<string,Set<string>>(),results:MatchResult[]=[];
 const events=matches.flatMap(m=>[{kind:'start' as const,time:Date.parse(m.startedAt??m.finishedAt),match:m},{kind:'finish' as const,time:Date.parse(m.finishedAt),match:m}]);
 events.sort((a,b)=>a.time-b.time||a.match.createdAt.localeCompare(b.match.createdAt)||a.match.id.localeCompare(b.match.id)||(a.kind==='start'?-1:1));
 const seen=new Set<string>();
 for(const event of events){const m=event.match;for(const p of m.players)if(!players.has(p.name))players.set(p.name,{name:p.name,globalElo:500,globalGames:0,scoreTotal:0,seasonElo:450,seasonGames:0,achievedAt:null});
  const start=Date.parse(m.startedAt??m.finishedAt),finish=Date.parse(m.finishedAt);
  const withinSeason=start>=SEASON_START&&finish<SEASON_END&&finish>=start;
  const validAsync=m.timeSource==='reported'||m.mode!=='回合制'||(!!m.startedAt&&start<ASYNC_START_END&&finish-start<=15*86400000);
  if(event.kind==='start'){
   const eligible=new Set<string>();
   if(withinSeason&&validAsync)for(const p of m.players){const state=players.get(p.name)!;
    eligible.add(p.name);
   }qualified.set(m.id,eligible);continue;
  }
  if(seen.has(m.id))continue;seen.add(m.id);
  const before=m.players.map(p=>({...players.get(p.name)!,rank:p.rank})),deltas=matchDeltas(before,policy);
  const changes=m.players.map((p,i)=>{const state=players.get(p.name)!,d=deltas[i];
   const initiallyQualified=qualified.get(m.id)?.has(p.name)??false;
   const autoNpc=state.seasonElo>=550||state.seasonGames>=15;
   const counted=initiallyQualified&&!autoNpc;
   const bonus=counted&&m.platform==='Studio'?5:0,seasonDelta=counted?d.seasonDelta:0;
   let reason=counted?'已计分':autoNpc?'自动NPC：赛季成绩已锁定':!withinSeason?'非初赛时段：仅计全阶段分':!validAsync?'回合制开桌时间或时长不符：仅计全阶段分':'开桌或结算时已达资格限制：仅计全阶段分';
   const seasonAfter=counted?Math.min(550,state.seasonElo+seasonDelta+bonus):state.seasonElo;
   const seasonCapAdjustment=seasonAfter-(state.seasonElo+seasonDelta+bonus);
   if(counted&&seasonAfter>=550)reason='本局达到550，赛季分锁定为550';
   else if(counted&&state.seasonGames+1===15)reason='本局满15局，赛季成绩锁定';
   const change={autoNpc,seasonCapAdjustment,name:p.name,globalBefore:state.globalElo,globalDelta:d.globalDelta,globalAfter:state.globalElo+d.globalDelta,seasonBefore:state.seasonElo,seasonDelta,bonus,seasonAfter,seasonGames:state.seasonGames+(counted?1:0),seasonCounted:counted,reason};
   state.globalElo=change.globalAfter;state.globalGames++;state.scoreTotal+=p.score;state.seasonElo=change.seasonAfter;state.seasonGames=change.seasonGames;
   if(counted&&state.seasonElo>=550&&!state.achievedAt)state.achievedAt=m.finishedAt;
   if(counted&&(state.seasonElo>=550||state.seasonGames>=15)&&!state.lockedAt)state.lockedAt=m.finishedAt;
   return change;
  });results.push({id:m.id,players:changes});
 }
 const all=[...players.values()];
 for(const p of all){p.seasonLocked=p.seasonElo>=550||p.seasonGames>=15;p.lockReason=p.seasonElo>=550?'550':p.seasonGames>=15?'15局':null;p.lockedAt=p.lockedAt??null;}
 return {global:all.sort((a,b)=>b.globalElo-a.globalElo||a.name.localeCompare(b.name,'zh-CN')).map((p,i)=>({...p,rank:i+1,avgScore:p.globalGames?p.scoreTotal/p.globalGames:0})),season:all.filter(p=>p.seasonGames>0).sort((a,b)=>b.seasonElo-a.seasonElo||(a.seasonElo>=550?(a.seasonGames-b.seasonGames||Date.parse(a.achievedAt!)-Date.parse(b.achievedAt!)):0)||a.name.localeCompare(b.name,'zh-CN')).map((p,i)=>({...p,rank:i+1})),results,count:seen.size};
}
