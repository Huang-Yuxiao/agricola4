import { z } from 'zod';
import { canonicalName, identityKey } from './identity';
const player = z.object({name:z.string().trim().min(1,'请填写四位玩家').max(40).transform(canonicalName),score:z.number().finite().min(-1000).max(10000),rank:z.number().int().min(1).max(4),npc:z.boolean()});
export const submissionSchema = z.object({
  id:z.string().uuid(), platform:z.enum(['BGA','Studio']),tableId:z.string().trim().min(1,'请填写桌号').max(80).regex(/^[\w-]+$/,'桌号仅支持字母、数字、下划线和短横线'),
  mode:z.enum(['即时','回合制']),finishedAt:z.string().datetime().optional(),startedAt:z.string().datetime().optional(),
  note:z.string().trim().max(500),players:z.array(player).length(4)
}).superRefine((v,c)=>{
  if(new Set(v.players.map(p=>identityKey(p.name))).size!==4)c.addIssue({code:'custom',message:'四位玩家不能重复，历史别名也视为同一人'});
  if(!v.players.some(p=>p.rank===1))c.addIssue({code:'custom',message:'请设置第一名'});
  if(v.players.some(p=>p.rank!==1+v.players.filter(q=>q.rank<p.rank).length))c.addIssue({code:'custom',message:'并列后的名次需保留原位置，例如第二、三名并列应填 1、2、2、4'});
  if(v.players.some(p=>v.players.some(q=>(p.rank<q.rank&&p.score<q.score)||(p.rank===q.rank&&p.score!==q.score))))c.addIssue({code:'custom',message:'名次与得分不一致；真正并列请填相同得分，同分破平可填不同名次'});
  if(v.startedAt&&v.finishedAt&&v.startedAt>v.finishedAt)c.addIssue({code:'custom',message:'结束时间不能早于开桌时间'});
  if(v.finishedAt&&Date.parse(v.finishedAt)>Date.now()+300000)c.addIssue({code:'custom',message:'不能上报尚未结束的对局'});
  if(v.finishedAt&&Date.parse(v.finishedAt)<Date.parse('2026-10-02T00:00:00+08:00'))c.addIssue({code:'custom',message:'此入口接收2026年10月2日起的新对局，请勿重复上报已计入历史基线的旧成绩'});
});
export type Submission = z.infer<typeof submissionSchema>;
