"""Read-only prize projections from all surviving preliminary matches.

Money is exposed in yuan; proportional shares are rounded only for display.
These are allocations/projections, never a payment ledger.
"""
from decimal import Decimal
from ratings import START, END, stamp

PRIZE_RULE_VERSION = '2026autumn-prizes-v1'
RANK_AWARDS = [420, 348, 276, 204] + [75] * 4 + [40] * 8
TOTAL_POOL = 2350
HIGHEST_POOL = 50
PLACEMENT_RESERVE = sum(RANK_AWARDS)
SHARED_POOL = max(300, TOTAL_POOL - HIGHEST_POOL - PLACEMENT_RESERVE)
TOURNAMENT_END = stamp('2026-12-01T00:00:00+08:00')


def calculate_prizes(matches, season):
    # Work on the complete dataset, not the 200-match public history window.
    games = {}; best = {}; seen = set(); match_count = 0
    for m in matches:
        if m.get('stage') == 'historical' or not START <= stamp(m['finishedAt']) < TOURNAMENT_END:
            continue
        if m['id'] in seen:
            continue
        seen.add(m['id'])
        preliminary = stamp(m['finishedAt']) < END
        match_count += int(preliminary)
        for p in m['players']:
            name = p['name']
            games[name] = games.get(name, 0) + int(preliminary)
            score = Decimal(str(p.get('rawScore', p['score'])))
            if 'rawScore' not in p:
                score -= Decimal(str(p.get('tieBreakBonus', 0)))
            best[name] = max(best.get(name, score), score)
    ranks = {p['name']: p['rank'] for p in season}
    counted = {p['name']: p['seasonGames'] for p in season}
    qualified = {name for name, rank in ranks.items() if rank <= 16}
    eligible = {name for name, count in games.items() if count >= 6 and name not in qualified}
    weights = {name: max(0, count - 6) for name, count in games.items()}
    weight_total = sum(weights.values())
    half = SHARED_POOL / 2
    highest = max(best.values()) if best else None
    winners = sorted(name for name, score in best.items() if score == highest)
    rows = []
    for name, count in games.items():
        rank = ranks.get(name)
        advancing = name in qualified
        participation = half / len(eligible) if name in eligible else 0
        # Individual counterfactual: all other players keep their current status.
        hypothetical_count = len(eligible) + int(count >= 6 and name not in eligible)
        hypothetical = half / hypothetical_count if count >= 6 else 0
        activity = half * weights[name] / weight_total if weight_total else 0
        placement = RANK_AWARDS[rank - 1] if advancing else 0
        highest_share = HIGHEST_POOL / len(winners) if name in winners else 0
        rows.append(dict(name=name, rank=rank, playedGames=count,
                         scoredGames=counted.get(name, 0), extraGames=weights[name],
                         projectedQualified=advancing, participation=participation,
                         participationIfNotQualified=hypothetical,
                         hypotheticalParticipantCount=hypothetical_count,
                         activity=activity, currentAllocation=participation + activity,
                         projectedPlacement=placement,
                         projectedTotal=placement + participation + activity,
                         personalBest=float(best[name]), highestCandidate=highest_share))
    rows.sort(key=lambda p: (p['rank'] if p['rank'] is not None else 10**9, p['name']))
    return dict(ruleVersion=PRIZE_RULE_VERSION, totalPool=TOTAL_POOL,
                placementReserve=PLACEMENT_RESERVE, sharedPool=SHARED_POOL,
                participationPool=half, activityPool=half, highestPool=HIGHEST_POOL,
                participantCount=len(eligible), activityWeight=weight_total,
                activityParticipants=sum(w > 0 for w in weights.values()),
                matchCount=match_count, playerCount=len(rows),
                unallocatedParticipation=half if not eligible else 0,
                unallocatedActivity=half if not weight_total else 0,
                highestScore=float(highest) if highest is not None else None,
                highestPlayers=winners, rows=rows)
