"""Local administrator import; never exposed through the anonymous POST endpoint."""
import argparse,json,sqlite3
from pathlib import Path
from datetime import datetime,timezone
from contextlib import closing
from app import connection,DB,validate,SEED
from ratings import calculate_rankings

def run(path,apply=False):
    document=json.loads(Path(path).read_text(encoding='utf8'))
    batch=document['batch']; now=datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
    normalized=[]
    for item in document['matches']:
        m=validate(item)
        assert item['stage']=='historical' and item['importBatch']==batch
        assert type(item['historicalOrder'])==int and item['historicalOrder']>0
        assert all(p['name'] in {s['name'] for s in SEED} for p in m['players'])
        m.update(stage='historical',historicalOrder=item['historicalOrder'],importBatch=batch)
        normalized.append(m)
    assert len({m['historicalOrder'] for m in normalized})==len(normalized)
    assert len({m['id'] for m in normalized})==len(normalized)
    assert len({(m['platform'],m['tableId']) for m in normalized})==len(normalized)
    with connection() as con:
        con.execute('BEGIN IMMEDIATE')
        rows=con.execute('SELECT * FROM submissions ORDER BY created_at,id').fetchall()
        existing=[dict(json.loads(r['payload']),createdAt=r['created_at']) for r in rows]
        old_ids={m['id']:m for m in existing}; old_tables={(m['platform'],m['tableId']):m for m in existing}
        orders={m['historicalOrder']:m['id'] for m in existing if m.get('stage')=='historical'}
        pending=[]
        for m in normalized:
            old=old_ids.get(m['id'])
            if old:
                assert all(old.get(k)==v for k,v in m.items()),'回执已有不同内容，停止导入'
                continue
            assert (m['platform'],m['tableId']) not in old_tables,'补录编号冲突'
            assert m['historicalOrder'] not in orders,'历史顺序冲突'
            m.update(finishedAt=now,timeSource='reported',createdAt=now)
            pending.append(m)
        before=calculate_rankings(SEED,existing)
        after=calculate_rankings(SEED,existing+pending)
        results={r['id']:r for r in after['results']}
        assert all(not p['seasonCounted'] and p['seasonDelta']==0 and p['bonus']==0 for m in normalized for p in results[m['id']]['players'])
        if apply and pending:
            backup=Path(DB).parent/(Path(DB).stem+'-before-'+batch+'-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.sqlite3')
            with closing(sqlite3.connect(DB)) as source,closing(sqlite3.connect(backup)) as target:source.backup(target)
            for m in pending:
                data={k:v for k,v in m.items() if k!='createdAt'}
                con.execute('INSERT INTO submissions VALUES(?,?,?,?,?)',(m['id'],m['platform'],m['tableId'],json.dumps(data,ensure_ascii=False,sort_keys=True,separators=(',',':')),m['createdAt']))
            print('Backup:',backup)
        touched={p['name'] for m in normalized for p in m['players']}
        bp={p['name']:p for p in before['global_']}
        print(json.dumps(dict(applied=apply,inserted=len(pending),total=after['count'],seasonPlayers=len(after['season']),changes=[dict(name=p['name'],before=bp[p['name']]['globalElo'],after=p['globalElo'],gamesBefore=bp[p['name']]['globalGames'],gamesAfter=p['globalGames'],seasonGames=p['seasonGames']) for p in after['global_'] if p['name'] in touched]),ensure_ascii=False,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('path');parser.add_argument('--apply',action='store_true');args=parser.parse_args()
    run(args.path,args.apply)
