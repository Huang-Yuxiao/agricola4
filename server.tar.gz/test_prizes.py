import unittest
from prizes import calculate_prizes


def match(i, names=('a', 'b', 'c', 'd'), **extra):
    return dict(id=str(i), finishedAt='2026-10-09T00:00:00Z',
                players=[dict(name=n, score=60-j, rank=j+1, npc=True) for j,n in enumerate(names)], **extra)


class PrizeTests(unittest.TestCase):
    def test_poster_totals_and_no_division_by_zero(self):
        d=calculate_prizes([], [])
        self.assertEqual(d['placementReserve'],1868)
        self.assertEqual(d['sharedPool'],432)
        self.assertEqual(d['totalPool'],d['placementReserve']+d['sharedPool']+d['highestPool'])
        self.assertEqual((d['unallocatedParticipation'],d['unallocatedActivity']),(216,216))
        self.assertEqual(d['rows'],[])

    def test_all_games_count_including_npc_over15_and_beyond200(self):
        ms=[match(i) for i in range(205)]
        d=calculate_prizes(ms,[dict(name='a',rank=1,seasonGames=4)])
        a=next(p for p in d['rows'] if p['name']=='a')
        self.assertEqual((a['playedGames'],a['scoredGames'],a['extraGames']),(205,4,199))
        self.assertEqual(a['activity'],54)
        self.assertEqual(a['projectedPlacement'],420)
        self.assertEqual(a['participation'],0)
        self.assertEqual(a['participationIfNotQualified'],54)
        self.assertEqual(sum(p['participation'] for p in d['rows']),216)
        self.assertEqual(sum(p['activity'] for p in d['rows']),216)

    def test_six_game_threshold_and_current_vs_projected(self):
        ms=[match(i) for i in range(6)]
        d=calculate_prizes(ms,[dict(name=n,rank=i+1,seasonGames=4) for i,n in enumerate('abc')])
        a,b,c,out=d['rows']
        self.assertEqual(a['currentAllocation'],0)
        self.assertEqual(a['projectedTotal'],420)
        self.assertEqual(a['participationIfNotQualified'],108)
        self.assertEqual(out['participation'],216)
        self.assertEqual(out['projectedTotal'],216)
        self.assertEqual(d['activityWeight'],0)
        self.assertTrue(all(p['participation']==0 for p in calculate_prizes(ms[:5],[])['rows']))

    def test_highest_uses_raw_score_and_splits_per_id_not_game(self):
        ms=[match(0),match(1)]
        ms[0]['players'][0].update(score=70.001,rawScore=70,tieBreakBonus=.001)
        ms[1]['players'][0].update(score=70)
        ms[1]['players'][1].update(score=70)
        d=calculate_prizes(ms,[])
        self.assertEqual(d['highestScore'],70)
        self.assertEqual(d['highestPlayers'],['a','b'])
        self.assertEqual([p['highestCandidate'] for p in d['rows']],[25,25,0,0])

    def test_historical_excluded_finals_high_score_included(self):
        old=match('old',stage='historical');old['players'][0]['score']=999
        final=match('final');final['finishedAt']='2026-11-30T15:59:59Z';final['players'][2]['score']=80
        after=match('after');after['finishedAt']='2026-11-30T16:00:00Z';after['players'][1]['score']=900
        d=calculate_prizes([old,match(1),final,after],[])
        self.assertEqual(d['highestPlayers'],['c'])
        self.assertEqual(d['matchCount'],1)
        self.assertTrue(all(p['playedGames']==1 for p in d['rows']))

    def test_edit_delete_replays_counts_and_highest(self):
        ms=[match(i) for i in range(7)]
        ms[-1]['players'][0]['score']=90
        self.assertEqual(calculate_prizes(ms,[])['highestScore'],90)
        changed=calculate_prizes(ms[:-1],[])
        self.assertEqual(changed['highestScore'],60)
        self.assertEqual(changed['activityWeight'],0)
        self.assertEqual(changed,calculate_prizes(list(reversed(ms[:-1])),[]))

if __name__=='__main__':unittest.main()
