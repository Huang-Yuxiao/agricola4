"""Raw-score statistics, replayed from the complete surviving match list."""
from decimal import Decimal
import json
from pathlib import Path
from ratings import START, stamp
HISTORICAL_STATS=json.loads((Path(__file__).parent/'historical-stats.json').read_text(encoding='utf-8'))

SEASON_STATS_END=stamp('2026-12-01T00:00:00+08:00')

def add_player_stats(rankings,seed,matches,gyms,historical_stats=None):
    historical_stats=HISTORICAL_STATS if historical_stats is None else historical_stats
    stats={}
    def state(name):
        return stats.setdefault(name,dict(total=Decimal(0),games=0,maximum=None,complete=True,seasonTotal=Decimal(0),seasonGames=0,seasonMaximum=None))
    for row in seed:
        s=state(row['name']);count=int(row['games'])
        s['total']=Decimal(str(row['avg_score']))*count;s['games']=count
        s['complete']=count==0 or row.get('max_score') is not None
        if row.get('max_score') is not None:s['maximum']=Decimal(str(row['max_score']))
        recovered=historical_stats.get(row['name'])
        if recovered and recovered['games']==count:
            s['total']=Decimal(str(recovered['scoreTotal']))
            s['maximum']=Decimal(str(recovered['maxScore'])) if recovered['maxScore'] is not None else None
            s['complete']=True
    seen=set()
    for match in matches:
        if match['id'] in seen:continue
        seen.add(match['id'])
        season=match.get('stage')!='historical' and START<=stamp(match['finishedAt'])<SEASON_STATS_END
        for player in match['players']:
            s=state(player['name'])
            raw=Decimal(str(player.get('rawScore',player['score'])))
            if 'rawScore' not in player:raw-=Decimal(str(player.get('tieBreakBonus',0)))
            s['total']+=raw;s['games']+=1
            s['maximum']=raw if s['maximum'] is None else max(s['maximum'],raw)
            if season:
                s['seasonTotal']+=raw;s['seasonGames']+=1
                s['seasonMaximum']=raw if s['seasonMaximum'] is None else max(s['seasonMaximum'],raw)
    for board in ('global','season'):
        for player in rankings[board]:
            s=state(player['name'])
            player.update(gym=gyms.get(player['name'],''),
                globalAvgScore=float(s['total']/s['games']) if s['games'] else None,
                globalMaxScore=float(s['maximum']) if s['maximum'] is not None else None,
                globalMaxComplete=s['complete'],globalStatsGames=s['games'],
                seasonAvgScore=float(s['seasonTotal']/s['seasonGames']) if s['seasonGames'] else None,
                seasonMaxScore=float(s['seasonMaximum']) if s['seasonMaximum'] is not None else None,
                seasonPlayedGames=s['seasonGames'])
