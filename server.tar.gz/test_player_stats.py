import unittest,json
from pathlib import Path
from player_stats import add_player_stats,HISTORICAL_STATS
class StatsTests(unittest.TestCase):
    def test_historical_seed_covers_every_confirmed_player(self):
        seed=json.loads((Path(__file__).parent/'history.json').read_text(encoding='utf-8'))
        self.assertEqual(len(HISTORICAL_STATS),len(seed))
        for p in seed:
            s=HISTORICAL_STATS[p['name']]
            self.assertEqual(s['games'],int(p['games']))
            if s['games']:
                self.assertLessEqual(abs(s['scoreTotal']/s['games']-float(p['avg_score'])),0.006)
                self.assertGreaterEqual(s['maxScore'],s['scoreTotal']/s['games'])

    def test_raw_scores_include_npc_and_more_than_fifteen_or_200_matches(self):
        board={'global':[dict(name='a')],'season':[dict(name='a')]}
        seed=[dict(name='a',games=1,avg_score=40)]
        matches=[dict(id=str(i),finishedAt='2026-10-03T00:00:00Z',players=[dict(name='a',score=50.001,rawScore=50,tieBreakBonus=.001,manualNpc=True,npc=True)]) for i in range(201)]
        matches+=[dict(id='historic',stage='historical',finishedAt='2025-10-03T00:00:00Z',players=[dict(name='a',score=70)])]
        add_player_stats(board,seed,matches,{'a':'北京'},{'a':dict(games=1,scoreTotal=40,maxScore=40)})
        for p in (board['global'][0],board['season'][0]):
            self.assertEqual(p['seasonPlayedGames'],201)
            self.assertEqual(p['seasonAvgScore'],50);self.assertEqual(p['seasonMaxScore'],50)
            self.assertEqual(p['globalStatsGames'],203);self.assertEqual(p['globalMaxScore'],70)
            self.assertAlmostEqual(p['globalAvgScore'],(40+201*50+70)/203)
            self.assertTrue(p['globalMaxComplete']);self.assertEqual(p['gym'],'北京')
        matches.pop();matches.pop()
        add_player_stats(board,seed,matches,{}, {'a':dict(games=1,scoreTotal=40,maxScore=40)})
        self.assertEqual(board['global'][0]['globalMaxScore'],50)
        self.assertEqual(board['season'][0]['seasonPlayedGames'],200)
