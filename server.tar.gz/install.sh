#!/bin/bash
set -euo pipefail
cd /opt/agricola4
id agricola >/dev/null 2>&1 || useradd --system --home-dir /var/lib/agricola4 --shell /sbin/nologin agricola
install -d -o agricola -g agricola -m 0750 /var/lib/agricola4 /var/backups/agricola4
/opt/wechat-tools/uv venv --python /opt/wechat-python/cpython-3.12.14-linux-x86_64-gnu/bin/python3 .venv
/opt/wechat-tools/uv pip install --python .venv/bin/python -r requirements.txt
.venv/bin/python -m unittest -v test_app
install -m 0644 agricola4.service /etc/systemd/system/agricola4.service
printf '%s\n' '17 4 * * * agricola /opt/agricola4/.venv/bin/python /opt/agricola4/backup.py' > /etc/cron.d/agricola4-backup
chmod 0644 /etc/cron.d/agricola4-backup
systemctl daemon-reload
systemctl enable --now agricola4
curl --fail http://127.0.0.1:8001/healthz
systemctl is-enabled agricola4
systemctl is-active agricola4
