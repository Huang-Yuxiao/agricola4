"""Deterministic replay of the confirmed 128-player baseline and new matches."""
from datetime import datetime

def stamp(value):
    return datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp()

START=stamp('2026-10-02T00:00:00+08:00')
END=stamp('2026-10-26T00:00:00+08:00')
ASYNC_END=stamp('2026-10-11T00:00:00+08:00')

def global_k(games):
    return 40 if games<10 else 80/3 if games<20 else 40/3

def expected(a,b):
    return 1/(1+10**((b-a)/400))

def calculate_rankings(seed,matches):
    states={p['name']:dict(name=p['name'],globalElo=float(p['elo']),globalGames=int(p['games']),scoreTotal=float(p['avg_score'])*int(p['games']),seasonElo=450,seasonGames=0,achievedAt=None) for p in seed}
    events=[]
    for m in matches:
        for kind,time in [('start',m.get('startedAt') or m['finishedAt']),('finish',m['finishedAt'])]:
            historical=m.get('stage')=='historical'
            events.append((0 if historical else 1,m['historicalOrder'] if historical else stamp(time),m['createdAt'],m['id'],0 if kind=='start' else 1,m))
    events.sort(key=lambda e:e[:5])
    slots={};qualified={};results=[];seen=set()
    for _,_,_,_,kind,m in events:
        for p in m['players']:
            states.setdefault(p['name'],dict(name=p['name'],globalElo=500,globalGames=0,scoreTotal=0,seasonElo=450,seasonGames=0,achievedAt=None))
        start=stamp(m.get('startedAt') or m['finishedAt']);finish=stamp(m['finishedAt'])
        within=m.get('stage')!='historical' and start>=START and finish<END and finish>=start
        valid_async=m.get('timeSource')=='reported' or m['mode']!='回合制' or (bool(m.get('startedAt')) and start<ASYNC_END and finish-start<=15*86400)
        if kind==0:
            eligible=set()
            if within and valid_async:
                for p in m['players']:
                    s=states[p['name']]
                    if not p['npc'] and s['seasonElo']<550 and s['seasonGames']<15 and slots.get(p['name'],0)<15:
                        eligible.add(p['name']);slots[p['name']]=slots.get(p['name'],0)+1
            qualified[m['id']]=eligible
            continue
        if m['id'] in seen:continue
        seen.add(m['id'])
        before=[dict(states[p['name']],rank=p['rank']) for p in m['players']]
        changes=[]
        for i,p in enumerate(m['players']):
            s=states[p['name']];b=before[i];gd=sd=0
            for j,q in enumerate(before):
                if i==j:continue
                w=1 if b['rank']<q['rank'] else .5 if b['rank']==q['rank'] else 0
                gd+=global_k(b['globalGames'])*(w-expected(b['globalElo'],q['globalElo']))
                sd+=(40/3)*(w-expected(b['seasonElo'],q['globalElo']))
            counted=p['name'] in qualified.get(m['id'],set()) and (m['mode']!='回合制' or (s['seasonElo']<550 and s['seasonGames']<15))
            bonus=5 if counted and m['platform']=='Studio' else 0
            sd=sd if counted else 0
            reason='历史补录：仅计全阶段分' if m.get('stage')=='historical' else '已计分' if counted else 'NPC：不计赛季分' if p['npc'] else '非初赛时段：仅计全阶段分' if not within else '回合制开桌时间或时长不符：仅计全阶段分' if not valid_async else '开桌或结算时已达资格限制：仅计全阶段分'
            change=dict(name=p['name'],globalBefore=s['globalElo'],globalDelta=gd,globalAfter=s['globalElo']+gd,seasonBefore=s['seasonElo'],seasonDelta=sd,bonus=bonus,seasonAfter=s['seasonElo']+sd+bonus,seasonGames=s['seasonGames']+int(counted),seasonCounted=counted,reason=reason)
            s.update(globalElo=change['globalAfter'],globalGames=s['globalGames']+1,scoreTotal=s['scoreTotal']+p['score'],seasonElo=change['seasonAfter'],seasonGames=change['seasonGames'])
            if counted and s['seasonElo']>=550 and not s['achievedAt']:s['achievedAt']=m['finishedAt']
            changes.append(change)
        results.append(dict(id=m['id'],players=changes))
    glob=[dict(p,rank=i+1,avgScore=p['scoreTotal']/p['globalGames'] if p['globalGames'] else 0) for i,p in enumerate(sorted(states.values(),key=lambda p:(-p['globalElo'],p['name'])))]
    season=[dict(p,rank=i+1) for i,p in enumerate(sorted((p for p in states.values() if p['seasonGames']>0),key=lambda p:(-p['seasonElo'],p['name'])))]
    return dict(global_=glob,season=season,results=results,count=len(seen))
