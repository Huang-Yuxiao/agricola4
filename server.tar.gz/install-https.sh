#!/bin/bash
set -euo pipefail
cd /opt/agricola4
test -s /etc/letsencrypt/live/140.143.126.83/fullchain.pem
test -x /usr/local/bin/caddy
mkdir -p /var/lib/agricola-caddy
/usr/local/bin/caddy validate --config /opt/agricola4/Caddyfile --adapter caddyfile
install -m 0644 agricola-caddy.service agricola-cert-renew.service agricola-cert-renew.timer /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now agricola-caddy agricola-cert-renew.timer
systemctl is-active agricola4 agricola-caddy agricola-cert-renew.timer
/opt/agricola4/.venv/bin/python -c 'import urllib.request; print(urllib.request.urlopen("http://127.0.0.1:8001/healthz").read().decode())'
systemctl list-timers agricola-cert-renew.timer --no-pager
