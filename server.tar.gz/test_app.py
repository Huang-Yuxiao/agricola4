import copy, json, os, sqlite3, tempfile, unittest, uuid
from datetime import datetime,timezone
from pathlib import Path
tmp=tempfile.TemporaryDirectory()
os.environ['AGRICOLA_DB']=str(Path(tmp.name)/'scores.sqlite3')
from app import app, DB, score_center, initialize
from ratings import calculate_rankings

class RatingTests(unittest.TestCase):
    def test_matches_typescript_reference(self):
        fixture=json.loads((Path(__file__).parent/'golden.json').read_text(encoding='utf-8'))
        actual=calculate_rankings(fixture['seed'],fixture['matches'])
        actual['global']=actual.pop('global_')
        expected=fixture['result']
        self.assertEqual(actual['count'],expected['count'])
        for field in ['global','season']:
            actual_players={p['name']:p for p in actual[field]}
            for p in expected[field]:
                for key,val in p.items():
                    if key=='rank':continue  # deterministic tie ordering differs by locale
                    if isinstance(val,(int,float)) and not isinstance(val,bool):self.assertAlmostEqual(actual_players[p['name']][key],val,places=9)
                    else:self.assertEqual(actual_players[p['name']][key],val)
        for r,e in zip(actual['results'],expected['results']):
            self.assertEqual(r['id'],e['id'])
            for p,q in zip(r['players'],e['players']):
                for k,v in q.items():
                    if type(v) in [int,float]:self.assertAlmostEqual(p[k],v,places=9)
                    else:self.assertEqual(p[k],v)

class ApiTests(unittest.TestCase):
    def setUp(self):
        self.client=app.test_client()
        self.origin={'Origin':'https://huang-yuxiao.github.io'}
        self.data=dict(id=str(uuid.uuid4()),platform='BGA',mode='即时',tableId='TEST-'+uuid.uuid4().hex,finishedAt=datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z'),note='',players=[dict(name='test'+str(i),score=s,rank=r,npc=False) for i,(s,r) in enumerate([(60,1),(50,2),(50,2),(40,4)])])
    def test_save_retry_collision_and_persistence(self):
        response=self.client.post('/api/submissions',json=self.data,headers=self.origin)
        self.assertEqual(response.status_code,201)
        self.assertEqual(response.headers['Access-Control-Allow-Origin'],self.origin['Origin'])
        self.assertEqual(self.client.post('/api/submissions',json=self.data,headers=self.origin).status_code,200)
        dup=dict(self.data,id=str(uuid.uuid4()))
        self.assertEqual(self.client.post('/api/submissions',json=dup,headers=self.origin).status_code,409)
        first=score_center();initialize();self.assertEqual(score_center(),first)
        item=next(m for m in first['items'] if m['id']==self.data['id'])
        self.assertEqual(item['ratingChanges'][1]['globalAfter'],500)
        self.assertEqual(item['ratingChanges'][1]['seasonGames'],1)
    def test_validation_and_origin(self):
        self.assertEqual(self.client.post('/api/submissions',json=self.data,headers={'Origin':'https://evil.invalid'}).status_code,403)
        self.assertEqual(self.client.options('/api/submissions',headers=self.origin).status_code,204)
        bad=copy.deepcopy(self.data);bad['players'][0]['name']='门';bad['players'][1]['name']='qazxswedc'
        self.assertEqual(self.client.post('/api/submissions',json=bad).status_code,400)
        bad=copy.deepcopy(self.data);bad['players'][2]['score']=49
        self.assertEqual(self.client.post('/api/submissions',json=bad).status_code,400)
        bad=copy.deepcopy(self.data);bad['players'][3]['rank']=3
        self.assertEqual(self.client.post('/api/submissions',json=bad).status_code,400)
        bad=copy.deepcopy(self.data);bad['finishedAt']='2026-01-01T00:00:00Z'
        self.assertEqual(self.client.post('/api/submissions',json=bad).status_code,400)

if __name__=='__main__':unittest.main()
