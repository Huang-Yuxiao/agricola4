import copy, json, os, sqlite3, tempfile, unittest, uuid
from datetime import datetime,timezone
from unittest.mock import patch
from pathlib import Path
tmp=tempfile.TemporaryDirectory()
os.environ['AGRICOLA_DB']=str(Path(tmp.name)/'scores.sqlite3')
from app import app, DB, score_center, initialize, connection
from ratings import calculate_rankings

class RatingTests(unittest.TestCase):
    def test_historical_before_current_and_no_season(self):
        seed=[dict(name='p'+str(i),elo='500',games='0',avg_score='0') for i in range(4)]
        def match(i,historical=False):
            m=dict(id=str(i),platform='BGA',mode='即时',finishedAt='2026-10-03T00:00:00Z',createdAt='2026-10-03T00:00:00Z',players=[dict(name='p'+str(j),rank=j+1,score=65-5*j,npc=False) for j in range(4)])
            if historical:m.update(stage='historical',historicalOrder=i)
            return m
        first=match(1,True);second=match(2,True);current=match(0)
        actual=calculate_rankings(seed,[current,second,first])
        self.assertEqual([r['id'] for r in actual['results']],['1','2','0'])
        for r in actual['results'][:2]:
            self.assertTrue(all(not p['seasonCounted'] and p['seasonDelta']==0 and p['bonus']==0 for p in r['players']))
        self.assertTrue(all(p['seasonGames']==1 and p['globalGames']==3 for p in actual['global_']))

    def test_matches_typescript_reference(self):
        fixture=json.loads((Path(__file__).parent/'golden.json').read_text(encoding='utf-8'))
        actual=calculate_rankings(fixture['seed'],fixture['matches'])
        actual['global']=actual.pop('global_')
        expected=fixture['result']
        self.assertEqual(actual['count'],expected['count'])
        for field in ['global','season']:
            actual_players={p['name']:p for p in actual[field]}
            for p in expected[field]:
                for key,val in p.items():
                    if key=='rank':continue  # deterministic tie ordering differs by locale
                    if isinstance(val,(int,float)) and not isinstance(val,bool):self.assertAlmostEqual(actual_players[p['name']][key],val,places=9)
                    else:self.assertEqual(actual_players[p['name']][key],val)
        for r,e in zip(actual['results'],expected['results']):
            self.assertEqual(r['id'],e['id'])
            for p,q in zip(r['players'],e['players']):
                for k,v in q.items():
                    if type(v) in [int,float]:self.assertAlmostEqual(p[k],v,places=9)
                    else:self.assertEqual(p[k],v)

class ApiTests(unittest.TestCase):
    def setUp(self):
        with connection() as con:con.execute('DELETE FROM submissions')
        self.client=app.test_client()
        self.origin={'Origin':'https://huang-yuxiao.github.io'}
        self.data=dict(id=str(uuid.uuid4()),platform='BGA',mode='即时',tableId='TEST-'+uuid.uuid4().hex,finishedAt=datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z'),note='',players=[dict(name='test'+str(i),score=s,rank=r,npc=False) for i,(s,r) in enumerate([(60,1),(50,2),(50,2),(40,4)])])
    def test_save_retry_collision_and_persistence(self):
        response=self.client.post('/api/submissions',json=self.data,headers=self.origin)
        self.assertEqual(response.status_code,201)
        self.assertEqual(response.headers['Access-Control-Allow-Origin'],self.origin['Origin'])
        self.assertEqual(self.client.post('/api/submissions',json=self.data,headers=self.origin).status_code,200)
        dup=dict(self.data,id=str(uuid.uuid4()))
        self.assertEqual(self.client.post('/api/submissions',json=dup,headers=self.origin).status_code,409)
        first=score_center();initialize();self.assertEqual(score_center(),first)
        item=next(m for m in first['items'] if m['id']==self.data['id'])
        self.assertEqual(item['ratingChanges'][1]['globalAfter'],500)
        self.assertEqual(item['ratingChanges'][1]['seasonGames'],1)
    def test_equal_scores_with_distinct_ranks_adjust_once(self):
        data=copy.deepcopy(self.data)
        for i,p in enumerate(data['players']):p.update(score=[58,52,39,39][i],rank=i+1)
        self.assertEqual(self.client.post('/api/submissions',json=data,headers=self.origin).status_code,201)
        first=next(m for m in score_center()['items'] if m['id']==data['id'])
        self.assertEqual([p['score'] for p in first['players']],[58,52,39.001,39])
        self.assertEqual(first['players'][2]['rawScore'],39)
        self.assertEqual(self.client.post('/api/submissions',json=data,headers=self.origin).status_code,200)
        self.assertEqual(next(m for m in score_center()['items'] if m['id']==data['id']),first)
        from app import apply_score_tiebreaks
        tied=[dict(name=str(i),score=47,rank=r,npc=False) for i,r in enumerate([1,2,3,3])]
        self.assertEqual([p['score'] for p in apply_score_tiebreaks(tied)],[47.002,47.001,47,47])
        existing=[dict(name=str(i),score=s,rank=r,npc=False) for i,(s,r) in enumerate([(55,1),(47.001,2),(47,3),(47,3)])]
        self.assertEqual(apply_score_tiebreaks(existing),existing)

    def test_validation_and_origin(self):
        self.assertEqual(self.client.post('/api/submissions',json=self.data,headers={'Origin':'https://evil.invalid'}).status_code,403)
        self.assertEqual(self.client.options('/api/submissions',headers=self.origin).status_code,204)
        bad=copy.deepcopy(self.data);bad['players'][0]['name']='门';bad['players'][1]['name']='qazxswedc'
        self.assertEqual(self.client.post('/api/submissions',json=bad).status_code,400)
        bad=copy.deepcopy(self.data);bad['players'][2]['score']=49
        self.assertEqual(self.client.post('/api/submissions',json=bad).status_code,400)
        bad=copy.deepcopy(self.data);bad['players'][3]['rank']=3
        self.assertEqual(self.client.post('/api/submissions',json=bad).status_code,400)
        bad=copy.deepcopy(self.data);bad['finishedAt']='2026-01-01T00:00:00Z'
        self.assertEqual(self.client.post('/api/submissions',json=bad).status_code,400)

    def test_historical_updates_totals_but_is_not_public_record(self):
        historic=copy.deepcopy(self.data)
        historic.update(stage='historical',historicalOrder=1)
        with connection() as con:
            con.execute('INSERT INTO submissions VALUES(?,?,?,?,?)',(historic['id'],historic['platform'],historic['tableId'],json.dumps(historic),historic['finishedAt']))
        result=self.client.get('/api/submissions',headers=self.origin).json
        self.assertEqual(result['items'],[])
        self.assertEqual(result['rankings']['count'],0)
        self.assertEqual(result['rankings']['season'],[])
        player=next(p for p in result['rankings']['global'] if p['name']=='test0')
        self.assertEqual(player['globalGames'],1)
        self.assertEqual(player['avgScore'],60)
        self.assertEqual(player['globalElo'],560)
        self.assertEqual(player['seasonElo'],450)
        self.assertEqual(self.client.post('/api/submissions',json=self.data,headers=self.origin).status_code,409)
        current=copy.deepcopy(self.data);current.update(id=str(uuid.uuid4()),tableId='PUBLIC-'+uuid.uuid4().hex)
        self.assertEqual(self.client.post('/api/submissions',json=current,headers=self.origin).status_code,201)
        result=self.client.get('/api/submissions',headers=self.origin).json
        self.assertEqual([m['id'] for m in result['items']],[current['id']])
        self.assertEqual(result['rankings']['count'],1)


    def test_auto_time_both_modes_and_delayed_retry(self):
        for mode in ['即时','回合制']:
            data=copy.deepcopy(self.data)
            data.update(id=str(uuid.uuid4()),tableId=uuid.uuid4().hex,mode=mode)
            data.pop('finishedAt')
            # After the former async opening deadline: new reports still count.
            with patch('app.datetime') as clock:
                clock.now.return_value=datetime(2026,10,20,12,0,tzinfo=timezone.utc)
                self.assertEqual(self.client.post('/api/submissions',json=data,headers=self.origin).status_code,201)
                first=next(m for m in score_center()['items'] if m['id']==data['id'])
                self.assertEqual(first['finishedAt'],first['createdAt'])
                self.assertEqual(first['timeSource'],'reported')
                self.assertNotIn('startedAt',first)
                self.assertTrue(all(c['seasonCounted'] for c in first['ratingChanges']))
                clock.now.return_value=datetime(2026,10,21,12,0,tzinfo=timezone.utc)
                response=self.client.post('/api/submissions',json=data,headers=self.origin)
                self.assertEqual(response.status_code,200)
                self.assertTrue(response.json['replayed'])
                self.assertEqual(next(m for m in score_center()['items'] if m['id']==data['id']),first)
                data['note']='changed'
                self.assertEqual(self.client.post('/api/submissions',json=data,headers=self.origin).status_code,409)

if __name__=='__main__':unittest.main()
