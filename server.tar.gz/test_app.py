import copy, json, os, sqlite3, tempfile, unittest, uuid
from datetime import datetime,timezone
from unittest.mock import patch
from pathlib import Path
from werkzeug.security import generate_password_hash
tmp=tempfile.TemporaryDirectory()
os.environ['AGRICOLA_DB']=str(Path(tmp.name)/'scores.sqlite3')
from app import app, DB, score_center, initialize, connection
from ratings import calculate_rankings

class RatingTests(unittest.TestCase):
    @staticmethod
    def season_match(i,group='p',platform='Studio',tied=False):
        end=datetime(2026,10,3,i//60,i%60,tzinfo=timezone.utc).isoformat().replace('+00:00','Z')
        return dict(id=group+str(i),createdAt=end,finishedAt=end,platform=platform,mode='即时',players=[dict(name=group+str(j),rank=1 if tied else j+1,score=60 if tied else 65-5*j,npc=True) for j in range(4)])

    def test_https_gateway_routes_every_public_api_endpoint(self):
        import fnmatch,re
        config=(Path(__file__).parent/'Caddyfile').read_text(encoding='utf-8')
        paths=next(line.split()[2:] for line in config.splitlines() if line.strip().startswith('@api path '))
        for rule in app.url_map.iter_rules():
            route=str(rule)
            if not (route.startswith('/api/') or route=='/healthz'):continue
            sample=re.sub(r'<[^>]+>','test',route)
            self.assertTrue(any(fnmatch.fnmatchcase(sample,pattern) for pattern in paths),'Public API missing from HTTPS gateway: '+route)

    def test_two_three_four_player_coefficients_and_studio_bonus(self):
        from ratings import global_k,season_k
        for count,k in [(2,20),(3,15),(4,40/3)]:
            self.assertEqual(season_k(count),k)
            for games,factor in [(0,3),(9,3),(10,2),(19,2),(20,1)]:
                self.assertEqual(global_k(games,count),factor*k)
            m=self.season_match(0);m['players']=m['players'][:count]
            with patch('ratings.expected',return_value=.5):r=calculate_rankings([], [m])
            for i,c in enumerate(r['results'][0]['players']):
                delta=k*((count-1-i)-i)/2
                self.assertAlmostEqual(c['seasonDelta'],delta)
                self.assertAlmostEqual(c['globalDelta'],3*delta)
                self.assertEqual(c['bonus'],5)
                self.assertEqual(c['seasonGames'],1)
            tied=copy.deepcopy(m)
            for player in tied['players']:player.update(rank=1,score=50)
            with patch('ratings.expected',return_value=.5):r=calculate_rankings([], [tied])
            self.assertTrue(all(c['seasonDelta']==0 and c['bonus']==5 for c in r['results'][0]['players']))

    def test_cap_550_and_auto_npc_without_manual_choice(self):
        matches=[self.season_match(i) for i in range(6)]
        with patch('ratings.expected',return_value=.4):
            result=calculate_rankings([],matches)
            unlocked=calculate_rankings([],matches[:3])
        p=next(p for p in result['season'] if p['name']=='p0')
        self.assertEqual((p['seasonElo'],p['seasonGames'],p['globalGames']),(550,4,6))
        self.assertTrue(p['seasonLocked']);self.assertEqual(p['lockReason'],'550')
        self.assertEqual(p['achievedAt'],matches[3]['finishedAt'])
        crossing=result['results'][3]['players'][0]
        self.assertEqual(crossing['seasonBefore'],537)
        self.assertEqual(crossing['seasonAfter'],550)
        self.assertEqual(crossing['seasonCapAdjustment'],-16)
        self.assertTrue(crossing['seasonCounted']);self.assertFalse(crossing['autoNpc'])
        for r in result['results'][4:]:
            c=r['players'][0]
            self.assertTrue(c['autoNpc']);self.assertFalse(c['seasonCounted'])
            self.assertEqual((c['seasonAfter'],c['seasonGames'],c['bonus'],c['seasonDelta']),(550,4,0,0))
            self.assertGreater(c['globalAfter'],c['globalBefore'])
        prior=next(p for p in unlocked['season'] if p['name']=='p0')
        self.assertEqual(prior['seasonElo'],537);self.assertFalse(prior['seasonLocked'])
        self.assertIsNone(prior['achievedAt'])

    def test_exact_550_and_rank_by_games_then_crossing_time(self):
        matches=([self.season_match(i,'B','BGA') for i in range(5)]
                 +[self.season_match(i,'A') for i in range(5,9)]
                 +[self.season_match(i,'C') for i in range(9,13)])
        with patch('ratings.expected',return_value=.5):result=calculate_rankings([],list(reversed(matches)))
        finishers=[p for p in result['season'] if p['seasonElo']==550]
        self.assertEqual([p['name'] for p in finishers],['A0','C0','B0'])
        self.assertEqual([p['seasonGames'] for p in finishers],[4,4,5])
        self.assertTrue(all(p['seasonLocked'] for p in finishers))

    def test_fifteenth_game_locks_and_overlapping_games_cannot_bypass(self):
        matches=[self.season_match(i,tied=True) for i in range(17)]
        for m in matches:m.update(mode='回合制',startedAt='2026-10-03T00:00:00Z')
        with patch('ratings.expected',return_value=.5):result=calculate_rankings([],matches)
        for p in result['season']:
            self.assertEqual((p['seasonElo'],p['seasonGames'],p['globalGames']),(525,15,17))
            self.assertTrue(p['seasonLocked']);self.assertEqual(p['lockReason'],'15局')
            self.assertEqual(p['lockedAt'],matches[14]['finishedAt']);self.assertIsNone(p['achievedAt'])
        self.assertTrue(all(c['seasonCounted'] for c in result['results'][14]['players']))
        self.assertTrue(all(c['autoNpc'] and c['bonus']==0 for c in result['results'][15]['players']))

    def test_studio_bonus_is_season_only(self):
        seed=[dict(name='p'+str(i),elo='500',games='0',avg_score='0') for i in range(4)]
        m=dict(id='one',platform='BGA',mode='即时',finishedAt='2026-10-03T00:00:00Z',createdAt='2026-10-03T00:00:00Z',players=[dict(name='p'+str(i),rank=i+1,score=65-i*5,npc=i==3) for i in range(4)])
        normal=calculate_rankings(seed,[m])
        studio=calculate_rankings(seed,[dict(m,platform='Studio')])
        for b,g in zip(normal['results'][0]['players'],studio['results'][0]['players']):
            self.assertEqual(g['globalAfter'],b['globalAfter'])
            self.assertEqual(g['globalDelta'],b['globalDelta'])
            self.assertEqual(g['seasonAfter']-b['seasonAfter'],5)
            self.assertEqual(g['bonus'],5)

    def test_historical_before_current_and_no_season(self):
        seed=[dict(name='p'+str(i),elo='500',games='0',avg_score='0') for i in range(4)]
        def match(i,historical=False):
            m=dict(id=str(i),platform='BGA',mode='即时',finishedAt='2026-10-03T00:00:00Z',createdAt='2026-10-03T00:00:00Z',players=[dict(name='p'+str(j),rank=j+1,score=65-5*j,npc=False) for j in range(4)])
            if historical:m.update(stage='historical',historicalOrder=i)
            return m
        first=match(1,True);second=match(2,True);current=match(0)
        actual=calculate_rankings(seed,[current,second,first])
        self.assertEqual([r['id'] for r in actual['results']],['1','2','0'])
        for r in actual['results'][:2]:
            self.assertTrue(all(not p['seasonCounted'] and p['seasonDelta']==0 and p['bonus']==0 for p in r['players']))
        self.assertTrue(all(p['seasonGames']==1 and p['globalGames']==3 for p in actual['global_']))

    def test_manual_sequence_controls_lock_replay_without_changing_times(self):
        matches=[self.season_match(i) for i in range(17)]
        for i,m in enumerate(matches):
            m['sequence']=(i*7)%17+1
            for j,p in enumerate(m['players']):
                p['rank']=(j+i)%4+1;p['score']=70-5*p['rank']
        reordered=sorted(matches,key=lambda m:m['sequence'])
        reference=copy.deepcopy(reordered)
        for i,m in enumerate(reference):
            m.pop('sequence');m.update(finishedAt=f'2026-10-03T00:{i:02d}:00Z',createdAt=f'2026-10-03T00:{i:02d}:00Z')
        actual=calculate_rankings([],matches);expected=calculate_rankings([],reference)
        self.assertEqual(actual['results'],expected['results'])
        self.assertEqual([r['id'] for r in actual['results']],[m['id'] for m in reordered])
        for player in actual['season']:
            other=next(p for p in expected['season'] if p['name']==player['name'])
            for field in ('globalElo','globalGames','scoreTotal','seasonElo','seasonGames','seasonLocked','lockReason'):self.assertEqual(player[field],other[field])
        self.assertTrue(all(p['seasonLocked'] for p in actual['season']))

    def test_matches_typescript_reference(self):
        fixture=json.loads((Path(__file__).parent/'golden.json').read_text(encoding='utf-8'))
        actual=calculate_rankings(fixture['seed'],fixture['matches'])
        actual['global']=actual.pop('global_')
        expected=fixture['result']
        self.assertEqual(actual['count'],expected['count'])
        for field in ['global','season']:
            actual_players={p['name']:p for p in actual[field]}
            for p in expected[field]:
                for key,val in p.items():
                    if key=='rank':continue  # deterministic tie ordering differs by locale
                    if isinstance(val,(int,float)) and not isinstance(val,bool):self.assertAlmostEqual(actual_players[p['name']][key],val,places=9)
                    else:self.assertEqual(actual_players[p['name']][key],val)
        for r,e in zip(actual['results'],expected['results']):
            self.assertEqual(r['id'],e['id'])
            for p,q in zip(r['players'],e['players']):
                for k,v in q.items():
                    if type(v) in [int,float]:self.assertAlmostEqual(p[k],v,places=9)
                    else:self.assertEqual(p[k],v)

class ApiTests(unittest.TestCase):
    def setUp(self):
        with connection() as con:
            for table in ['submissions','deleted_submissions','admin_failures','submission_order','submission_audit','registered_players','player_profiles']:con.execute('DELETE FROM '+table)
            con.executemany('INSERT INTO registered_players VALUES(?,?,?)',[(f'test{i}',f'test{i}','2026-10-02T00:00:00Z') for i in range(4)])
        self.client=app.test_client()
        self.origin={'Origin':'https://huang-yuxiao.github.io'}
        self.data=dict(id=str(uuid.uuid4()),platform='BGA',mode='即时',tableId='TEST-'+uuid.uuid4().hex,finishedAt=datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z'),note='',players=[dict(name='test'+str(i),score=s,rank=r,npc=False) for i,(s,r) in enumerate([(60,1),(50,2),(50,2),(40,4)])])

    def make_matches(self,n=3):
        matches=[]
        for i in range(n):
            data=copy.deepcopy(self.data);data.update(id=str(uuid.uuid4()),tableId='ORDER-'+str(i),platform='Studio',finishedAt=f'2026-10-03T00:0{i}:00Z')
            for j,p in enumerate(data['players']):
                rank=(j+i)%4+1;p.update(rank=rank,score=70-5*rank)
            self.assertEqual(self.client.post('/api/submissions',json=data,headers=self.origin).status_code,201)
            matches.append(data)
        return matches

    def admin(self,mid,action,**body):
        with patch.dict(os.environ,{'AGRICOLA_ADMIN_PASSWORD_HASH':generate_password_hash('unit-test-password')}):
            return self.client.post(f'/api/submissions/{mid}/{action}',json=dict(password='unit-test-password',**body),headers=self.origin)

    def assert_replay(self,center,matches=None):
        from app import SEED
        expected=calculate_rankings(SEED,center['items'] if matches is None else matches)
        for board,target in [('global','global_'),('season','season')]:
            for actual,original in zip(center['rankings'][board],expected[target]):
                self.assertEqual({k:actual[k] for k in original},original)

    def test_public_gym_edit_shared_persistent_and_concurrent_safe(self):
        self.make_matches(1)
        url='/api/players/gym';data=dict(name='TEST0',gym='  北京   道馆 ',expectedGym='')
        self.assertEqual(self.client.options(url,headers=self.origin).status_code,204)
        self.assertEqual(self.client.post(url,json=data,headers={'Origin':'https://evil.invalid'}).status_code,403)
        self.assertEqual(self.client.post(url,json=dict(data,name='not registered')).status_code,404)
        self.assertEqual(self.client.post(url,json=dict(data,gym='x'*61)).status_code,400)
        before=score_center();saved=self.client.post(url,json=data,headers=self.origin)
        self.assertEqual(saved.status_code,200);self.assertEqual(saved.json['gym'],'北京 道馆')
        initialize();after=score_center()
        for board in ('global','season'):
            p=next(p for p in after['rankings'][board] if p['name']=='test0')
            self.assertEqual(p['gym'],'北京 道馆')
        self.assertEqual(before['items'],after['items']);self.assertEqual(before['prizes'],after['prizes'])
        self.assertEqual(self.client.post(url,json=data).status_code,409)
        self.assertEqual(self.client.post(url,json=dict(data,gym='',expectedGym='北京 道馆')).status_code,200)
        self.assertEqual(next(p for p in score_center()['rankings']['global'] if p['name']=='test0')['gym'],'')

    def test_registered_ids_require_admin_persist_and_cannot_duplicate(self):
        url='/api/players'
        with patch.dict(os.environ,{'AGRICOLA_ADMIN_PASSWORD_HASH':generate_password_hash('unit-test-password')}):
            self.assertEqual(self.client.post(url,json={'name':'New Player'}).status_code,400)
            self.assertEqual(self.client.post(url,json={'name':'New Player','password':'wrong'}).status_code,403)
            good={'name':'  New   Player  ','password':'unit-test-password'}
            self.assertEqual(self.client.post(url,json=good,headers={'Origin':'https://evil.invalid'}).status_code,403)
            self.assertEqual(self.client.post(url,json=good,headers=self.origin).status_code,201)
            for name in ('new player','Ｎｅｗ Player','门','qazxswedc'):
                self.assertEqual(self.client.post(url,json=dict(good,name=name)).status_code,409)
            self.assertEqual(self.client.post(url,json=dict(good,name='x\u0000y')).status_code,400)
        initialize()
        p=next(p for p in score_center()['rankings']['global'] if p['name']=='New Player')
        self.assertEqual((p['globalElo'],p['globalGames'],p['avgScore']),(500,0,0))
        self.assertFalse(any(p['name']=='New Player' for p in score_center()['prizes']['rows']))
        data=copy.deepcopy(self.data);data['players']=data['players'][:2];data['players'][0]['name']='new PLAYER'
        self.assertEqual(self.client.post('/api/submissions',json=data).status_code,201)
        self.assertEqual(score_center()['items'][0]['players'][0]['name'],'New Player')
        item=score_center()['items'][0]
        self.assertEqual(self.admin(item['id'],'delete').status_code,200)
        self.assertTrue(any(p['name']=='New Player' and p['globalGames']==0 for p in score_center()['rankings']['global']))

    def test_two_three_player_submit_edit_npc_and_reject_unknown_or_partial(self):
        for count in (2,3):
            data=copy.deepcopy(self.data);data.update(id=str(uuid.uuid4()),tableId='COUNT-'+str(count),platform='Studio',finishedAt='2026-10-03T01:00:00Z')
            data['players']=data['players'][:count]
            for i,p in enumerate(data['players']):p.update(rank=i+1,score=60-5*i)
            self.assertEqual(self.client.post('/api/submissions',json=data).status_code,201)
            item=next(m for m in score_center()['items'] if m['id']==data['id'])
            self.assertEqual(len(item['players']),count)
            self.assertEqual(self.admin(item['id'],'npc',revision=item['revision'],npcNames=[data['players'][0]['name']]).status_code,200)
            item=next(m for m in score_center()['items'] if m['id']==data['id'])
            self.assertFalse(item['ratingChanges'][0]['seasonCounted'])
            self.assertEqual(self.admin(item['id'],'edit',revision=item['revision'],submission=data).status_code,200)
        for count in (0,1,5):
            data=copy.deepcopy(self.data);data['players']=(data['players']*2)[:count]
            self.assertEqual(self.client.post('/api/submissions',json=data).status_code,400)
        for name in ('Unregistered Name',''):
            data=copy.deepcopy(self.data);data['players'][0]['name']=name
            self.assertEqual(self.client.post('/api/submissions',json=data).status_code,400)
        data=copy.deepcopy(self.data);data['players']=data['players'][:2];data['players'][1]['rank']=3
        self.assertEqual(self.client.post('/api/submissions',json=data).status_code,400)
        with connection() as con:self.assertEqual(con.execute('SELECT COUNT(*) FROM submissions').fetchone()[0],2)

    def test_manual_npc_is_protected_reversible_and_preserved_on_edit(self):
        matches=self.make_matches();before=score_center();item=before['items'][1]
        names=[p['name'] for p in item['players'][:2]]
        url=f"/api/submissions/{item['id']}/npc"
        with patch.dict(os.environ,{'AGRICOLA_ADMIN_PASSWORD_HASH':''}):
            self.assertEqual(self.client.post(url,json={'password':'wrong','revision':item['revision'],'npcNames':names},headers=self.origin).status_code,503)
        for invalid in (['outsider'],[names[0],names[0]],'all',[None]):
            self.assertEqual(self.admin(item['id'],'npc',revision=item['revision'],npcNames=invalid).status_code,400)
        self.assertEqual(self.admin(item['id'],'npc',revision='stale',npcNames=names).status_code,409)
        with patch.dict(os.environ,{'AGRICOLA_ADMIN_PASSWORD_HASH':generate_password_hash('unit-test-password')}):
            self.assertEqual(self.client.post(url,json={'password':'wrong','revision':item['revision'],'npcNames':names},headers=self.origin).status_code,403)
        self.assertEqual(self.admin(item['id'],'npc',revision=item['revision'],npcNames=names).status_code,200)
        after=score_center();marked=after['items'][1]
        for a,b in zip(after['rankings']['global'],before['rankings']['global']):
            for field in ('name','rank','globalElo','globalGames','scoreTotal','avgScore'):self.assertEqual(a[field],b[field])
        self.assertEqual({p['name']:(p['playedGames'],p['extraGames']) for p in after['prizes']['rows']},{p['name']:(p['playedGames'],p['extraGames']) for p in before['prizes']['rows']})
        for field in ('id','finishedAt','createdAt','sequence','scoringNumber'):self.assertEqual(marked[field],item[field])
        for p,c,old in zip(marked['players'],marked['ratingChanges'],item['ratingChanges']):
            self.assertEqual(c['globalAfter'],old['globalAfter'])
            if p['name'] in names:
                self.assertTrue(p['manualNpc']);self.assertTrue(p['npc'])
                self.assertEqual(c['seasonBefore'],c['seasonAfter'])
                self.assertEqual((c['bonus'],c['seasonDelta'],c['seasonCounted']),(0,0,False))
                self.assertIn('管理员指定NPC',c['reason'])
            else:self.assertEqual(c,old)
        self.assertEqual(self.admin(item['id'],'edit',revision=marked['revision'],submission=matches[1]).status_code,200)
        edited=score_center()['items'][1]
        self.assertEqual([p['name'] for p in edited['players'] if p.get('manualNpc')],names)
        self.assertEqual(self.admin(item['id'],'npc',revision=edited['revision'],npcNames=[]).status_code,200)
        restored=score_center()
        self.assertEqual(restored['rankings'],before['rankings'])
        self.assertEqual(restored['prizes'],before['prizes'])
        with connection() as con:self.assertGreaterEqual(con.execute("SELECT COUNT(*) FROM submission_audit WHERE action='npc'").fetchone()[0],2)

    def test_public_submit_cannot_assign_manual_npc(self):
        data=copy.deepcopy(self.data)
        for p in data['players']:p.update(manualNpc=True,npc=True)
        self.assertEqual(self.client.post('/api/submissions',json=data,headers=self.origin).status_code,201)
        self.assertTrue(all(not p.get('manualNpc') for p in score_center()['items'][0]['players']))

    def test_edit_preserves_identity_times_position_and_recomputes(self):
        matches=self.make_matches();before=score_center();item=before['items'][1]
        data=copy.deepcopy(matches[1]);data.update(note='corrected',tableId='CORRECTED',platform='BGA',finishedAt='2026-10-20T00:00:00Z',id=str(uuid.uuid4()))
        for p in data['players']:p['score']+=1
        response=self.admin(item['id'],'edit',revision=item['revision'],submission=data)
        self.assertEqual(response.status_code,200,response.json)
        after=score_center();edited=after['items'][1]
        for key in ('id','createdAt','finishedAt','sequence','scoringNumber'):self.assertEqual(edited[key],item[key])
        self.assertEqual([m['id'] for m in before['items']],[m['id'] for m in after['items']])
        self.assertNotEqual(before['rankings']['season'],after['rankings']['season'])
        self.assertNotEqual(before['rankings']['global'],after['rankings']['global'])
        self.assertEqual(edited['tableId'],'CORRECTED');self.assert_replay(after)
        self.assertEqual(self.admin(item['id'],'edit',revision=item['revision'],submission=data).status_code,409)
        initialize();self.assertEqual(score_center(),after)
        with connection() as con:self.assertEqual(con.execute('SELECT COUNT(*) FROM submission_audit').fetchone()[0],1)

    def test_edit_tiebreaks_and_cross_platform_unique_tables(self):
        matches=self.make_matches();item=score_center()['items'][-1]
        data=copy.deepcopy(matches[0]);data.update(platform='BGA',tableId=matches[1]['tableId'].lower())
        self.assertEqual(self.admin(item['id'],'edit',revision=item['revision'],submission=data).status_code,409)
        dup=copy.deepcopy(data);dup['id']=str(uuid.uuid4())
        self.assertEqual(self.client.post('/api/submissions',json=dup,headers=self.origin).status_code,409)
        data['tableId']=matches[0]['tableId']
        for i,p in enumerate(data['players']):p.update(rank=i+1,score=[58,52,39,39][i])
        self.assertEqual(self.admin(item['id'],'edit',revision=item['revision'],submission=data).status_code,200)
        edited=score_center()['items'][-1];self.assertEqual(edited['players'][2]['score'],39.001)
        self.assertEqual(self.admin(item['id'],'edit',revision=edited['revision'],submission=data).status_code,200)
        self.assertEqual(score_center()['items'][-1],edited)

    def test_move_both_directions_append_and_restore(self):
        matches=self.make_matches(4);before=score_center()
        a,b,c,d=[m['id'] for m in matches]
        self.assertEqual(self.admin(d,'move',beforeTableId='order-1').status_code,200)
        after=score_center();self.assertEqual([m['id'] for m in reversed(after['items'])],[a,d,b,c])
        self.assertNotEqual(after['rankings']['global'],before['rankings']['global']);self.assert_replay(after)
        # Independent reference uses synthetic chronological timestamps, not sequence.
        reference=[]
        for i,m in enumerate(reversed(after['items'])):
            m=dict(m);m.pop('sequence');m['finishedAt']=f'2026-10-03T00:0{i}:00Z';reference.append(m)
        from app import SEED
        self.assert_replay(after,reference)
        self.assertEqual(self.admin(a,'move',beforeTableId=matches[2]['tableId']).status_code,200)
        self.assertEqual([m['id'] for m in reversed(score_center()['items'])],[d,b,a,c])
        self.assertTrue(self.admin(a,'move',beforeTableId=matches[2]['tableId']).json['replayed'])
        original=score_center();self.assertEqual(self.admin(b,'delete').status_code,200)
        self.assertEqual(self.admin(a,'move',beforeTableId=matches[3]['tableId']).status_code,200)
        from restore_submission import restore
        restore(b)
        self.assertEqual([m['id'] for m in reversed(score_center()['items'])],[a,d,b,c])
        extra=copy.deepcopy(self.data);extra.update(id=str(uuid.uuid4()),tableId='APPENDED')
        self.assertEqual(self.client.post('/api/submissions',json=extra,headers=self.origin).status_code,201)
        self.assertEqual(score_center()['items'][0]['id'],extra['id'])
        initialize();self.assertEqual(score_center()['items'][0]['id'],extra['id'])

    def test_admin_edit_move_validation_and_authorization(self):
        matches=self.make_matches();item=score_center()['items'][0];before=score_center()
        for action in ('edit','move'):
            route=f"/api/submissions/{item['id']}/{action}"
            with patch.dict(os.environ,{'AGRICOLA_ADMIN_PASSWORD_HASH':generate_password_hash('unit-test-password')}):
                self.assertEqual(self.client.post(route,json={'password':'wrong'},headers=self.origin).status_code,403)
                self.assertEqual(self.client.post(route,json={'password':'unit-test-password'},headers={'Origin':'https://evil.invalid'}).status_code,403)
            self.assertEqual(self.client.options(route,headers=self.origin).status_code,204)
        self.assertEqual(self.admin(item['id'],'move',beforeTableId=item['tableId']).status_code,400)
        self.assertEqual(self.admin(item['id'],'move',beforeTableId='MISSING').status_code,404)
        self.assertEqual(self.admin(item['id'],'move',beforeTableId='???').status_code,400)
        bad=copy.deepcopy(matches[2]);bad['players'][1]['name']=bad['players'][0]['name']
        self.assertEqual(self.admin(item['id'],'edit',revision=item['revision'],submission=bad).status_code,400)
        self.assertEqual(score_center(),before)
        with connection() as con:
            historic=dict(matches[0],stage='historical',historicalOrder=1)
            con.execute('UPDATE submissions SET payload=? WHERE id=?',(json.dumps(historic),historic['id']))
        self.assertEqual(self.admin(item['id'],'move',beforeTableId=historic['tableId']).status_code,403)
        self.assertEqual(self.admin(historic['id'],'move',beforeTableId=item['tableId']).status_code,403)
        self.assertEqual(self.admin(historic['id'],'edit',revision='x',submission=bad).status_code,403)

    def test_order_migration_preserves_existing_calculation(self):
        matches=self.make_matches()
        before=score_center()
        with connection() as con:con.execute('DELETE FROM submission_order')
        initialize();self.assertEqual(score_center(),before)

    def test_npc_is_automatic_and_optional_for_submission(self):
        data=copy.deepcopy(self.data)
        for p in data['players']:p.pop('npc')
        self.assertEqual(self.client.post('/api/submissions',json=data,headers=self.origin).status_code,201)
        item=score_center()['items'][0]
        self.assertTrue(all(c['seasonCounted'] and not c['autoNpc'] for c in item['ratingChanges']))
        self.assertTrue(all(not p['npc'] for p in item['players']))
        legacy=copy.deepcopy(self.data);legacy.update(id=str(uuid.uuid4()),tableId='MANUAL-NPC-IGNORED')
        for p in legacy['players']:p['npc']=True
        self.assertEqual(self.client.post('/api/submissions',json=legacy,headers=self.origin).status_code,201)
        self.assertTrue(all(c['seasonCounted'] for c in score_center()['items'][0]['ratingChanges']))

    def test_password_delete_replay_and_restore(self):
        before=score_center()
        self.assertEqual(self.client.post('/api/submissions',json=self.data,headers=self.origin).status_code,201)
        second=copy.deepcopy(self.data);second.update(id=str(uuid.uuid4()),tableId='SECOND')
        second['players'].reverse()
        for i,p in enumerate(second['players']):p.update(rank=i+1,score=65-5*i)
        self.assertEqual(self.client.post('/api/submissions',json=second,headers=self.origin).status_code,201)
        both=score_center();route='/api/submissions/'+self.data['id']+'/delete'
        secret=generate_password_hash('unit-test-password')
        with patch.dict(os.environ,{'AGRICOLA_ADMIN_PASSWORD_HASH':''}):
            self.assertEqual(self.client.post(route,json={'password':'unit-test-password'},headers=self.origin).status_code,503)
        with patch.dict(os.environ,{'AGRICOLA_ADMIN_PASSWORD_HASH':secret}):
            self.assertEqual(self.client.post(route,json={'password':'wrong'},headers=self.origin).status_code,403)
            self.assertEqual(self.client.post(route,json={'password':'unit-test-password'},headers={'Origin':'https://evil.invalid'}).status_code,403)
            self.assertEqual(score_center(),both)
            self.assertEqual(self.client.options(route,headers=self.origin).status_code,204)
            self.assertEqual(self.client.post(route,json={'password':'unit-test-password'},headers=self.origin).status_code,200)
            after=score_center()
            self.assertEqual([m['id'] for m in after['items']],[second['id']])
            from app import SEED
            expected=calculate_rankings(SEED,[after['items'][0]])
            self.assert_replay(after)
            initialize();self.assertEqual(score_center(),after)
            self.assertTrue(self.client.post(route,json={'password':'unit-test-password'},headers=self.origin).json['replayed'])
            self.assertEqual(self.client.post('/api/submissions',json=self.data,headers=self.origin).status_code,409)
            from restore_submission import restore
            restore(self.data['id']);self.assertEqual(score_center(),both)
            historic=dict(self.data,stage='historical',historicalOrder=1)
            with connection() as con:con.execute('UPDATE submissions SET payload=? WHERE id=?',(json.dumps(historic),self.data['id']))
            self.assertEqual(self.client.post(route,json={'password':'unit-test-password'},headers=self.origin).status_code,403)

    def test_delete_password_rate_limit(self):
        route='/api/submissions/'+self.data['id']+'/delete'
        with patch.dict(os.environ,{'AGRICOLA_ADMIN_PASSWORD_HASH':generate_password_hash('unit-test-password')}):
            for _ in range(10):self.assertEqual(self.client.post(route,json={'password':'wrong'},headers=self.origin).status_code,403)
            self.assertEqual(self.client.post(route,json={'password':'wrong'},headers=self.origin).status_code,429)

    def test_save_retry_collision_and_persistence(self):
        response=self.client.post('/api/submissions',json=self.data,headers=self.origin)
        self.assertEqual(response.status_code,201)
        self.assertEqual(response.headers['Access-Control-Allow-Origin'],self.origin['Origin'])
        self.assertEqual(self.client.post('/api/submissions',json=self.data,headers=self.origin).status_code,200)
        dup=dict(self.data,id=str(uuid.uuid4()))
        self.assertEqual(self.client.post('/api/submissions',json=dup,headers=self.origin).status_code,409)
        first=score_center();initialize();self.assertEqual(score_center(),first)
        item=next(m for m in first['items'] if m['id']==self.data['id'])
        self.assertEqual(item['ratingChanges'][1]['globalAfter'],500)
        self.assertEqual(item['ratingChanges'][1]['seasonGames'],1)
    def test_equal_scores_with_distinct_ranks_adjust_once(self):
        data=copy.deepcopy(self.data)
        for i,p in enumerate(data['players']):p.update(score=[58,52,39,39][i],rank=i+1)
        self.assertEqual(self.client.post('/api/submissions',json=data,headers=self.origin).status_code,201)
        first=next(m for m in score_center()['items'] if m['id']==data['id'])
        self.assertEqual([p['score'] for p in first['players']],[58,52,39.001,39])
        self.assertEqual(first['players'][2]['rawScore'],39)
        self.assertEqual(self.client.post('/api/submissions',json=data,headers=self.origin).status_code,200)
        self.assertEqual(next(m for m in score_center()['items'] if m['id']==data['id']),first)
        from app import apply_score_tiebreaks
        tied=[dict(name=str(i),score=47,rank=r,npc=False) for i,r in enumerate([1,2,3,3])]
        self.assertEqual([p['score'] for p in apply_score_tiebreaks(tied)],[47.002,47.001,47,47])
        existing=[dict(name=str(i),score=s,rank=r,npc=False) for i,(s,r) in enumerate([(55,1),(47.001,2),(47,3),(47,3)])]
        self.assertEqual(apply_score_tiebreaks(existing),existing)

    def test_validation_and_origin(self):
        self.assertEqual(self.client.post('/api/submissions',json=self.data,headers={'Origin':'https://evil.invalid'}).status_code,403)
        self.assertEqual(self.client.options('/api/submissions',headers=self.origin).status_code,204)
        bad=copy.deepcopy(self.data);bad['players'][0]['name']='门';bad['players'][1]['name']='qazxswedc'
        self.assertEqual(self.client.post('/api/submissions',json=bad).status_code,400)
        bad=copy.deepcopy(self.data);bad['players'][2]['score']=49
        self.assertEqual(self.client.post('/api/submissions',json=bad).status_code,400)
        bad=copy.deepcopy(self.data);bad['players'][3]['rank']=3
        self.assertEqual(self.client.post('/api/submissions',json=bad).status_code,400)
        bad=copy.deepcopy(self.data);bad['finishedAt']='2026-01-01T00:00:00Z'
        self.assertEqual(self.client.post('/api/submissions',json=bad).status_code,400)

    def test_historical_updates_totals_but_is_not_public_record(self):
        historic=copy.deepcopy(self.data)
        historic.update(stage='historical',historicalOrder=1)
        with connection() as con:
            con.execute('INSERT INTO submissions VALUES(?,?,?,?,?)',(historic['id'],historic['platform'],historic['tableId'],json.dumps(historic),historic['finishedAt']))
        result=self.client.get('/api/submissions',headers=self.origin).json
        self.assertEqual(result['items'],[])
        self.assertEqual(result['rankings']['count'],0)
        self.assertEqual(result['rankings']['season'],[])
        player=next(p for p in result['rankings']['global'] if p['name']=='test0')
        self.assertEqual(player['globalGames'],1)
        self.assertEqual(player['avgScore'],60)
        self.assertEqual(player['globalElo'],560)
        self.assertEqual(player['seasonElo'],450)
        self.assertEqual(self.client.post('/api/submissions',json=self.data,headers=self.origin).status_code,409)
        current=copy.deepcopy(self.data);current.update(id=str(uuid.uuid4()),tableId='PUBLIC-'+uuid.uuid4().hex)
        self.assertEqual(self.client.post('/api/submissions',json=current,headers=self.origin).status_code,201)
        result=self.client.get('/api/submissions',headers=self.origin).json
        self.assertEqual([m['id'] for m in result['items']],[current['id']])
        self.assertEqual(result['rankings']['count'],1)


    def test_auto_time_both_modes_and_delayed_retry(self):
        for mode in ['即时','回合制']:
            data=copy.deepcopy(self.data)
            data.update(id=str(uuid.uuid4()),tableId=uuid.uuid4().hex,mode=mode)
            data.pop('finishedAt')
            # After the former async opening deadline: new reports still count.
            with patch('app.datetime') as clock:
                clock.now.return_value=datetime(2026,10,20,12,0,tzinfo=timezone.utc)
                self.assertEqual(self.client.post('/api/submissions',json=data,headers=self.origin).status_code,201)
                first=next(m for m in score_center()['items'] if m['id']==data['id'])
                self.assertEqual(first['finishedAt'],first['createdAt'])
                self.assertEqual(first['timeSource'],'reported')
                self.assertNotIn('startedAt',first)
                self.assertTrue(all(c['seasonCounted'] for c in first['ratingChanges']))
                clock.now.return_value=datetime(2026,10,21,12,0,tzinfo=timezone.utc)
                response=self.client.post('/api/submissions',json=data,headers=self.origin)
                self.assertEqual(response.status_code,200)
                self.assertTrue(response.json['replayed'])
                self.assertEqual(next(m for m in score_center()['items'] if m['id']==data['id']),first)
                data['note']='changed'
                self.assertEqual(self.client.post('/api/submissions',json=data,headers=self.origin).status_code,409)

if __name__=='__main__':unittest.main()
