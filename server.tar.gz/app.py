import json, math, os, re, sqlite3, unicodedata, uuid, hashlib
from pathlib import Path
from datetime import datetime, timezone
from contextlib import contextmanager
from decimal import Decimal
from flask import Flask, request, jsonify
from werkzeug.security import check_password_hash
import time
from ratings import calculate_rankings, stamp, START
from prizes import calculate_prizes

ROOT=Path(__file__).resolve().parent
SEED=json.loads((ROOT/'history.json').read_text(encoding='utf-8'))
ALIASES=json.loads((ROOT/'player-aliases.json').read_text(encoding='utf-8'))
ORIGIN=os.environ.get('AGRICOLA_ORIGIN','https://huang-yuxiao.github.io')
DB=os.environ.get('AGRICOLA_DB',str(ROOT/'data/scores.sqlite3'))
app=Flask(__name__)
app.config['MAX_CONTENT_LENGTH']=12000

def key(s):return ' '.join(unicodedata.normalize('NFKC',s).split()).lower()
NAMES={key(p['name']):p['name'] for p in SEED}
NAMES.update({key(a):n for a,n in ALIASES.items()})

@contextmanager
def connection():
    con=sqlite3.connect(DB,timeout=20)
    con.row_factory=sqlite3.Row
    con.execute('PRAGMA busy_timeout=20000')
    try:
        with con:yield con
    finally:con.close()

def initialize():
    Path(DB).parent.mkdir(parents=True,exist_ok=True)
    with connection() as con:
        con.execute('PRAGMA journal_mode=WAL')
        con.execute('CREATE TABLE IF NOT EXISTS submissions (id TEXT PRIMARY KEY, platform TEXT NOT NULL, table_id TEXT NOT NULL, payload TEXT NOT NULL, created_at TEXT NOT NULL, UNIQUE(platform,table_id))')
        con.execute('CREATE TABLE IF NOT EXISTS deleted_submissions (id TEXT PRIMARY KEY, platform TEXT NOT NULL, table_id TEXT NOT NULL, payload TEXT NOT NULL, created_at TEXT NOT NULL, deleted_at TEXT NOT NULL)')
        con.execute('CREATE TABLE IF NOT EXISTS admin_failures (attempted_at REAL NOT NULL)')
        con.execute('CREATE TABLE IF NOT EXISTS submission_order (id TEXT PRIMARY KEY, position INTEGER NOT NULL)')
        con.execute('CREATE TABLE IF NOT EXISTS submission_audit (id INTEGER PRIMARY KEY, submission_id TEXT NOT NULL, action TEXT NOT NULL, before_json TEXT NOT NULL, after_json TEXT NOT NULL, changed_at TEXT NOT NULL)')
        con.execute('BEGIN IMMEDIATE')
        ensure_order(con)

def ensure_order(con):
    # Keep deleted IDs too: restoring a deleted match preserves its scoring position.
    rows=con.execute('SELECT s.* FROM submissions s LEFT JOIN submission_order o ON o.id=s.id WHERE o.id IS NULL').fetchall()
    rows=sorted((r for r in rows if json.loads(r['payload']).get('stage')!='historical'),key=lambda r:(json.loads(r['payload'])['finishedAt'],r['created_at'],r['id']))
    position=con.execute('SELECT COALESCE(MAX(position),0) FROM submission_order').fetchone()[0]
    for row in rows:
        position+=1
        con.execute('INSERT INTO submission_order VALUES(?,?)',(row['id'],position))

def revision(payload):return hashlib.sha256(payload.encode('utf-8')).hexdigest()

def admin_error(con,data):
    secret=os.environ.get('AGRICOLA_ADMIN_PASSWORD_HASH','')
    if not secret:return jsonify(error='管理员功能尚未配置'),503
    password=data.get('password') if isinstance(data,dict) else None
    if not isinstance(password,str) or not 1<=len(password)<=256:return jsonify(error='请输入管理员密码'),400
    now=time.time()
    con.execute('DELETE FROM admin_failures WHERE attempted_at<?',(now-60,))
    if con.execute('SELECT COUNT(*) FROM admin_failures').fetchone()[0]>=10:return jsonify(error='密码尝试过于频繁，请1分钟后重试'),429
    if not check_password_hash(secret,password):
        con.execute('INSERT INTO admin_failures VALUES(?)',(now,))
        return jsonify(error='管理员密码错误'),403

def audit(con,submission_id,action,before,after):
    con.execute('INSERT INTO submission_audit(submission_id,action,before_json,after_json,changed_at) VALUES(?,?,?,?,?)',(submission_id,action,json.dumps(before,ensure_ascii=False),json.dumps(after,ensure_ascii=False),datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')))


@app.after_request
def headers(response):
    if request.headers.get('Origin')==ORIGIN:
        response.headers['Access-Control-Allow-Origin']=ORIGIN
        response.headers['Vary']='Origin'
        response.headers['Access-Control-Allow-Methods']='GET, POST, OPTIONS'
        response.headers['Access-Control-Allow-Headers']='Content-Type'
        response.headers['Access-Control-Max-Age']='600'
    response.headers['Cache-Control']='no-store'
    response.headers['X-Content-Type-Options']='nosniff'
    return response

def apply_score_tiebreaks(players):
    """Encode distinct rank tiers at an equal submitted score in 0.001 steps."""
    result=[]
    for p in players:
        tiers={q['rank'] for q in players if q['score']==p['score'] and q['rank']>p['rank']}
        adjusted=dict(p)
        if tiers:
            bonus=Decimal('0.001')*len(tiers)
            adjusted.update(rawScore=p['score'],tieBreakBonus=float(bonus),score=float(Decimal(str(p['score']))+bonus))
        result.append(adjusted)
    return result

def validate(data):
    if not isinstance(data,dict):raise ValueError('请求格式无效')
    fields=['id','platform','tableId','mode','note','players']
    if not all(f in data for f in fields):raise ValueError('请完整填写对局信息')
    data={f:data[f] for f in fields+['finishedAt','startedAt'] if f in data}
    if not isinstance(data['id'],str) or str(uuid.UUID(data['id']))!=data['id'].lower():raise ValueError('回执编号无效，请刷新页面')
    if data['platform'] not in ['BGA','Studio'] or data['mode'] not in ['即时','回合制']:raise ValueError('平台或模式无效')
    if not isinstance(data['tableId'],str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}',data['tableId'].strip()):raise ValueError('桌号仅支持字母、数字、下划线和短横线')
    data['tableId']=data['tableId'].strip()
    if not isinstance(data['note'],str) or len(data['note'].strip())>500:raise ValueError('备注最多500字')
    data['note']=data['note'].strip()
    for field in ['finishedAt','startedAt']:
        if field in data:
            if not isinstance(data[field],str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z',data[field]):raise ValueError('时间格式无效')
            stamp(data[field])
    finish=stamp(data['finishedAt']) if 'finishedAt' in data else datetime.now(timezone.utc).timestamp()
    if finish<START:raise ValueError('此入口接收2026年10月2日起的新对局，请勿重复上报已计入历史基线的旧成绩')
    if finish>datetime.now(timezone.utc).timestamp()+300:raise ValueError('不能上报尚未结束的对局')
    if data['mode']=='即时':data.pop('startedAt',None)
    if 'finishedAt' not in data:data.pop('startedAt',None)
    if data['mode']=='回合制' and 'finishedAt' in data and not data.get('startedAt'):raise ValueError('回合制请填写开桌时间')
    if data.get('startedAt') and stamp(data['startedAt'])>finish:raise ValueError('结束时间不能早于开桌时间')
    ps=data['players']
    if not isinstance(ps,list) or len(ps)!=4:raise ValueError('请填写四位玩家')
    for i,p in enumerate(ps):
        if not isinstance(p,dict) or not isinstance(p.get('name'),str):raise ValueError('玩家格式无效')
        name=' '.join(unicodedata.normalize('NFKC',p['name']).split())
        if not 1<=len(name)<=40:raise ValueError('玩家昵称需为1至40字')
        score=p.get('score');rank=p.get('rank');npc=False
        if type(score) not in [int,float] or not math.isfinite(score) or not -1000<=score<=10000:raise ValueError('得分无效')
        if type(rank)!=int or not 1<=rank<=4:raise ValueError('名次或NPC设置无效')
        ps[i]=dict(name=NAMES.get(key(name),name),score=score,rank=rank,npc=npc)
    if len({key(p['name']) for p in ps})!=4:raise ValueError('四位玩家不能重复，历史别名也视为同一人')
    if any(p['rank']!=1+sum(q['rank']<p['rank'] for q in ps) for p in ps):raise ValueError('并列后的名次需保留原位置，例如1、2、2、4')
    if any((p['rank']<q['rank'] and p['score']<q['score']) or (p['rank']==q['rank'] and p['score']!=q['score']) for p in ps for q in ps):raise ValueError('名次与得分不一致；真正并列请填相同得分')
    data['players']=apply_score_tiebreaks(ps)
    return data

def score_center():
    with connection() as con:rows=con.execute('SELECT s.*,o.position FROM submissions s LEFT JOIN submission_order o ON o.id=s.id ORDER BY s.created_at,s.id').fetchall()
    known=dict(NAMES);matches=[]
    for row in rows:
        m=json.loads(row['payload'])
        for p in m['players']:
            k=key(p['name']);p['name']=known.setdefault(k,p['name'])
        matches.append(dict(m,createdAt=row['created_at'],status='recorded',revision=revision(row['payload']),**({'sequence':row['position']} if row['position'] is not None else {})))
    matches.sort(key=lambda m:(0,m['historicalOrder']) if m.get('stage')=='historical' else (1,m.get('sequence',float('inf')),m['createdAt'],m['id']))
    rankings=calculate_rankings(SEED,matches)
    changes={r['id']:r['players'] for r in rankings.pop('results')}
    rankings['global']=rankings.pop('global_')
    public_matches=[m for m in matches if m.get('stage')!='historical']
    rankings['count']=len(public_matches)
    for i,m in enumerate(public_matches,1):m['scoringNumber']=i
    rankings.update(ruleVersion='2026autumn-admin-order-v3',baseline='用户确认的128人CSV起点',updatedAt=rows[-1]['created_at'] if rows else None)
    items=[]
    for m in reversed(public_matches[-200:]):
        player_changes=changes[m['id']]
        auto={c['name']:c['autoNpc'] for c in player_changes}
        items.append(dict(m,players=[dict(p,npc=auto[p['name']]) for p in m['players']],ratingChanges=player_changes))
    return dict(items=items,rankings=rankings,prizes=calculate_prizes(public_matches,rankings['season']))

@app.get('/healthz')
def health():
    with connection() as con:con.execute('SELECT 1').fetchone()
    return jsonify(ok=True,service='agricola4',ruleVersion='2026autumn-admin-order-v3')

@app.route('/api/submissions',methods=['GET','POST','OPTIONS'])
def submissions():
    origin=request.headers.get('Origin')
    if origin and origin!=ORIGIN:return jsonify(error='请求来源不受支持'),403
    if request.method=='OPTIONS':return '',204
    if request.method=='GET':return jsonify(score_center())
    if not request.is_json:return jsonify(error='请使用JSON提交'),415
    try:data=validate(request.get_json(silent=True))
    except ValueError as error:
        message=str(error)
        return jsonify(error=message if any('\u4e00'<=c<='\u9fff' for c in message) else '对局信息无效，请核对四人昵称、得分、名次及时间'),400
    except (TypeError,KeyError,OverflowError,AttributeError):return jsonify(error='对局信息无效，请核对四人昵称、得分、名次及时间'),400
    with connection() as con:
        con.execute('BEGIN IMMEDIATE')
        old=con.execute('SELECT payload FROM submissions WHERE id=?',(data['id'],)).fetchone()
        now=datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
        if 'finishedAt' not in data:
            previous=json.loads(old['payload']) if old else {}
            data['finishedAt']=previous['finishedAt'] if previous.get('timeSource')=='reported' else now
            data['timeSource']='reported'
        payload=json.dumps(data,ensure_ascii=False,sort_keys=True,separators=(',',':'))
        if old:
            if old['payload']==payload:return jsonify(id=data['id'],replayed=True),200
            return jsonify(error='此回执对应不同成绩，请勿修改后重复提交'),409
        if con.execute('SELECT 1 FROM deleted_submissions WHERE id=?',(data['id'],)).fetchone():return jsonify(error='此回执已删除，请重新填写上报'),409
        if con.execute('SELECT 1 FROM submissions WHERE table_id=? COLLATE NOCASE',(data['tableId'],)).fetchone():return jsonify(error='此桌号已上报，请在查对局中核对'),409
        con.execute('INSERT INTO submissions VALUES(?,?,?,?,?)',(data['id'],data['platform'],data['tableId'],payload,now))
        ensure_order(con)
    return jsonify(id=data['id']),201

@app.route('/api/submissions/<submission_id>/delete',methods=['POST','OPTIONS'])
def delete_submission(submission_id):
    origin=request.headers.get('Origin')
    if origin and origin!=ORIGIN:return jsonify(error='请求来源不受支持'),403
    if request.method=='OPTIONS':return '',204
    if not request.is_json:return jsonify(error='请使用JSON提交'),415
    data=request.get_json(silent=True)
    with connection() as con:
        con.execute('BEGIN IMMEDIATE')
        error=admin_error(con,data)
        if error:return error
        row=con.execute('SELECT * FROM submissions WHERE id=?',(submission_id,)).fetchone()
        if not row:
            if con.execute('SELECT 1 FROM deleted_submissions WHERE id=?',(submission_id,)).fetchone():return jsonify(id=submission_id,deleted=True,replayed=True)
            return jsonify(error='对局不存在，请刷新记录'),404
        if json.loads(row['payload']).get('stage')=='historical':return jsonify(error='历史基线对局不能在此删除'),403
        deleted_at=datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
        con.execute('INSERT INTO deleted_submissions VALUES(?,?,?,?,?,?)',tuple(row)+(deleted_at,))
        con.execute('DELETE FROM submissions WHERE id=?',(submission_id,))
    return jsonify(id=submission_id,deleted=True)


@app.route('/api/submissions/<submission_id>/<action>',methods=['POST','OPTIONS'])
def modify_submission(submission_id,action):
    if action not in ('edit','move'):return jsonify(error='操作不存在'),404
    origin=request.headers.get('Origin')
    if origin and origin!=ORIGIN:return jsonify(error='请求来源不受支持'),403
    if request.method=='OPTIONS':return '',204
    if not request.is_json:return jsonify(error='请使用JSON提交'),415
    body=request.get_json(silent=True)
    with connection() as con:
        con.execute('BEGIN IMMEDIATE')
        error=admin_error(con,body)
        if error:return error
        row=con.execute('SELECT * FROM submissions WHERE id=?',(submission_id,)).fetchone()
        if not row:return jsonify(error='对局不存在，请刷新记录'),404
        original=json.loads(row['payload'])
        if original.get('stage')=='historical':return jsonify(error='历史基线对局不能在此修改或调整顺序'),403
        ensure_order(con)
        if action=='edit':
            if body.get('revision')!=revision(row['payload']):return jsonify(error='这条记录已被修改，请关闭窗口、刷新后重新编辑'),409
            try:
                incoming=body.get('submission')
                if not isinstance(incoming,dict):raise ValueError('请完整填写对局信息')
                editable={k:incoming[k] for k in ('platform','tableId','mode','note','players') if k in incoming}
                data=validate(dict(editable,id=submission_id))
            except (ValueError,TypeError,KeyError,OverflowError,AttributeError) as exc:
                message=str(exc)
                return jsonify(error=message if any('\u4e00'<=c<='\u9fff' for c in message) else '对局信息无效，请核对昵称、得分和名次'),400
            if con.execute('SELECT 1 FROM submissions WHERE table_id=? COLLATE NOCASE AND id<>?',(data['tableId'],submission_id)).fetchone():return jsonify(error='此桌号已上报，请使用未占用的桌号'),409
            # Preserve all original timing/identity fields and scoring order.
            after=dict(original,**data)
            payload=json.dumps(after,ensure_ascii=False,sort_keys=True,separators=(',',':'))
            if payload!=row['payload']:
                audit(con,submission_id,'edit',original,after)
                con.execute('UPDATE submissions SET platform=?,table_id=?,payload=? WHERE id=?',(after['platform'],after['tableId'],payload,submission_id))
            return jsonify(id=submission_id,edited=True,revision=revision(payload))
        target=body.get('beforeTableId')
        if not isinstance(target,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}',target.strip()):return jsonify(error='请输入有效的目标桌号'),400
        target_row=con.execute('SELECT id,payload FROM submissions WHERE table_id=? COLLATE NOCASE',(target.strip(),)).fetchone()
        if not target_row:return jsonify(error='找不到目标桌号，请在查对局中核对'),404
        if target_row['id']==submission_id:return jsonify(error='不能插入到本局自己之前'),400
        if json.loads(target_row['payload']).get('stage')=='historical':return jsonify(error='不能插入历史基线对局之前'),403
        before=[r['id'] for r in con.execute('SELECT id FROM submission_order ORDER BY position,id')]
        after=list(before);after.remove(submission_id);after.insert(after.index(target_row['id']),submission_id)
        if before!=after:
            audit(con,submission_id,'move',before,after)
            con.executemany('UPDATE submission_order SET position=? WHERE id=?',[(i,mid) for i,mid in enumerate(after,1)])
        return jsonify(id=submission_id,moved=True,beforeTableId=target.strip(),replayed=before==after)

@app.errorhandler(413)
def too_big(error):return jsonify(error='提交内容过大'),413

initialize()
