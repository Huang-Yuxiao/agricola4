"""Restore an archived match: AGRICOLA_DB=... python restore_submission.py UUID."""
import argparse
from app import connection, ensure_order

def restore(submission_id):
    with connection() as con:
        con.execute('BEGIN IMMEDIATE')
        row=con.execute('SELECT id,platform,table_id,payload,created_at FROM deleted_submissions WHERE id=?',(submission_id,)).fetchone()
        if row is None:raise ValueError('No archived match with this ID')
        if con.execute('SELECT 1 FROM submissions WHERE table_id=? COLLATE NOCASE',(row['table_id'],)).fetchone():raise ValueError('Table number is already in use')
        con.execute('INSERT INTO submissions VALUES(?,?,?,?,?)',tuple(row))
        con.execute('DELETE FROM deleted_submissions WHERE id=?',(submission_id,))
        ensure_order(con)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('id')
    restore(parser.parse_args().id)
    print('Restored; rankings will be recalculated on the next read.')
