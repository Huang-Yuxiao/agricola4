"""Atomic daily SQLite online backup; retain 30 days."""
import sqlite3, pathlib, datetime
root=pathlib.Path('/var/backups/agricola4')
root.mkdir(parents=True,exist_ok=True)
today=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d')
with sqlite3.connect('/var/lib/agricola4/scores.sqlite3') as source,sqlite3.connect(root/f'scores-{today}.sqlite3') as target:source.backup(target)
for file in sorted(root.glob('scores-????????.sqlite3'))[:-30]:file.unlink()
